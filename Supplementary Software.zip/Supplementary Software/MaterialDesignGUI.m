function varargout = MaterialDesignGUI(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @MaterialDesignGUI_OpeningFcn, ...
    'gui_OutputFcn',  @MaterialDesignGUI_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
function MaterialDesignGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% Front panel image
try
    axes(handles.logo)
    
    data = load('images.mat');
    logo_Lab = data.img_logo;
    image(logo_Lab)
    
    axis off
    grid off
    set(handles.logo, 'Box', 'off')
    handles.logo.XRuler.Axle.LineStyle = 'none';
    handles.logo.YRuler.Axle.LineStyle = 'none';
    
    handles.img.rotation = data.img_rotation;
    handles.img.translation = data.img_translation;
    handles.img.screw = data.img_screw;
    handles.img.FACT = data.img_FACT;
catch
    errordlg('images.mat not found')
    return
end

opengl hardware

handles.tick_labels_to_show = 6; % Maximum number of values to show on x, y, or z axes

handles.nextColor = [0 0.44 0.74];
handles.prevColor = [0.85 0.32 0.1];
set(handles.step1_next, 'ForegroundColor', handles.nextColor)
set(handles.step2_next, 'ForegroundColor', handles.nextColor)
set(handles.step2_prev, 'ForegroundColor', handles.prevColor)
set(handles.step3_prev, 'ForegroundColor', handles.prevColor)

axes(handles.main_display)

handles.solver.dropdown_threshold = 250;
handles.solver.overall_threshold = 1e5;

handles.removal_depth = [];

handles.twistSet = false;
handles.fnum = 1;

handles.dithermode = 'dither';
set(handles.main_display,'XTick',[])
set(handles.main_display,'YTick',[])
set(handles.main_display,'ZTick',[])
xlabel([])
ylabel([])

handles.geometrySet = false;
handles.geometry = {'3', '3', '3', '10', '1', '0.1'};

handles.designSet = false;

handles.GIF.delay = 0.1;
handles.GIF.loopCount = inf;

set(handles.radio_rainbow, 'Value', 0)
set(handles.radio_twists, 'Value', 0)

set(handles.text_geometry, 'String', 'No geometry properties specified');
set(handles.text_twist, 'String', 'No twist(s) specified');

handles.step = 1;
axis equal
handles = UpdateDisplay(hObject, handles);
handles = PlotAxes(hObject, handles);
view([135 25])

handles.output = hObject;
guidata(hObject, handles);

function varargout = MaterialDesignGUI_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;

function handles = UpdateDisplay(hObject, handles)
handles.shadowOn = [0 0.447 0.741];
handles.shadowOff = [0.7 0.7 0.7];

% Turn everything off
set(handles.panel_step1, 'ShadowColor', handles.shadowOff)
set(handles.panel_step2, 'ShadowColor', handles.shadowOff)
set(handles.panel_step3, 'ShadowColor', handles.shadowOff)
set(handles.panel_step4, 'ShadowColor', handles.shadowOff)

set(handles.step1_next, 'Enable', 'off')
set(handles.step2_next, 'Enable', 'off')
set(handles.step2_prev, 'Enable', 'off')
set(handles.step3_prev, 'Enable', 'off')

set(handles.step1_setGeometry, 'Enable', 'off')

set(handles.step2_setTwist, 'Enable', 'off')
set(handles.step2_generateDesign, 'Enable', 'off')

set(handles.step3_screenshot, 'Enable', 'off')
set(handles.step3_animate, 'Enable', 'off')
set(handles.step3_cancel, 'Enable', 'off')

set(handles.step4_saveSTL, 'Enable', 'off')
set(handles.design_save, 'Enable','off')

set(handles.enter_frames, 'Enable', 'off')
set(handles.enter_mode, 'Enable', 'off')
set(handles.mode_minus, 'Enable', 'off')
set(handles.mode_plus, 'Enable', 'off')
set(handles.radio_rainbow, 'Enable', 'off')
set(handles.radio_twists, 'Enable', 'off')

if handles.step == 1
    set(handles.panel_step1, 'ShadowColor', handles.shadowOn)
    set(handles.step1_next, 'Enable', 'on')
    set(handles.step1_setGeometry, 'Enable', 'on')
    
    set(handles.step3_saveGIF, 'Enable', 'off')
elseif handles.step == 2
    set(handles.panel_step2, 'ShadowColor', handles.shadowOn)
    set(handles.step2_next, 'Enable', 'on')
    set(handles.step2_prev, 'Enable', 'on')
    set(handles.step2_setTwist, 'Enable', 'on')
    
    set(handles.step3_saveGIF, 'Enable', 'off')
    
    if handles.twistSet; set(handles.step2_generateDesign, 'Enable', 'on'); end
elseif handles.step == 3
    set(handles.panel_step3, 'ShadowColor', handles.shadowOn)
    set(handles.step3_prev, 'Enable', 'on')
    set(handles.step3_animate, 'Enable', 'on')
    set(handles.step3_screenshot, 'Enable', 'on')
    set(handles.enter_frames, 'Enable', 'on')
    set(handles.radio_rainbow, 'Enable', 'on')
    set(handles.radio_twists, 'Enable', 'on')
    set(handles.enter_mode, 'Enable', 'on')
    set(handles.mode_minus, 'Enable', 'on')
    set(handles.mode_plus, 'Enable', 'on')
    
    set(handles.panel_step4, 'ShadowColor', handles.shadowOn)
    set(handles.step4_saveSTL, 'Enable', 'on')
    
    set(handles.design_save, 'Enable','on')
end

handles = UpdateInstructions(hObject, handles);

guidata(hObject, handles)
function handles = UpdateInstructions(hObject, handles)
if handles.step == 1
    str = {'Step 1 requires the user to input geometric parameters that ';
        'define the geometry of the stacked rigid layers within the lattice.';
        ' ';
        ' Click on the ''Geometric properties'' button to enter: '; ...
        ' '; ...
        ' - The number of unit cells along the x-, y-, and z-axes'; ...
        ' '; ...
        ' - The side length of each unit-cell cube'; ...
        ' '; ...
        ' - The thickness of the rigid layers within each unit cell'; ...
        ' '; ...
        ' - The radius of the cylindrical wire-flexure elements within each cell';
        ' '; ...
        'Click the ''Next'' button to continue to the next step'};
elseif handles.step == 2
    str = {'Step 2 requires the user to input information pertaining to ';
        'the intermediate freedom spaces that each layer will possess.';
        'Click on the ''Input Twist'' button.'; ...
        
        ' - Enter the number of intermediate freedom spaces desired. Note that each space selected will pertain to each alternating layer within the lattice.'; ...
        
        ' - Use the FACT chart to select each desired intermediate freedom space from the yellow-highlighted region.'; ...
        
        ' - For each space selected, determine which independent DOFs from within that space you''d like to enter by choosing a corresponding twist vector and enter the information necessary to construct that vector.'; ...
        
        ' - Use the ''Generate design'' button to generate a topology that achieves the specified DOFs.'; ...
        ' '; ...
        'Click the ''Next'' button to continue to the next step or click the ''Previous'' button to go back a step.'};
elseif handles.step == 3
    str = {'Step 3 verifies and animates the DOFs of the generated design via modal analysis.';
        ' - Use the ''Display options'' to either show or not show the intended DOFs and/or the displacement colors.'; ...
        ' - Sort through the ''DOF'' index and use the ''Animate'' button to animate the corresponding DOFs.';
        ' - Enter the number of desired frames within the animation in the ''Frames'' box.';
        ' - Click ''Cancel'' to end the simulation if it''s taking too long.';
        ' - Click ''Save .gif'' to save the animation as a .gif file.';
        ' - Use the three different View options in the panel to see differnt views of the design.'
        'Click the ''Previous'' button to go back a step.'
        ' ';
        'Use the ''Import or export design'' panel to load or save a design. This panel can also be used to save the design as an .STL file or to save a screenshot of it. The .STL file can be used to 3D print the design.'};
end
set(handles.text_instructions, 'String', str)
guidata(hObject, handles)

%% Step 1
function handles = step1_setGeometry_Callback(hObject, eventdata, handles)
set(handles.text_geometry, 'String', 'No geometry properties specified');
guidata(hObject, handles)

prompts = {'Number of unit cells along the x-axis', ...
    'Number of unit cells along the y-axis', ...
    'Number of unit calls along the z-axis', ...
    'Side length of each unit-cell cube [m]', ...
    'Thickness of the rigid layers within each unit cell [m]', ...
    'Radius of the cylindrical wire-flexure elements within each cell [m]'};
Answer = inputdlg(prompts, 'Set geometric properties', 1, handles.geometry);
if isempty(Answer); return; end

handles.geometry = Answer;
handles.geometrySet = true;

handles = UpdateInstructions(hObject, handles);

xu = str2double(handles.geometry{1});
yu = str2double(handles.geometry{2});
zu = str2double(handles.geometry{3});
s = str2double(handles.geometry{4});
t = str2double(handles.geometry{5});

geo_str{1,1} = 'Geometry set:';
geo_str{2,1} = [' ' num2str(xu) ' by ' num2str(yu) ' by ' num2str(zu) ' unit cells'];
geo_str{3,1} = [' Unit cell side length: ' num2str(s,3) ' m'];
geo_str{4,1} = [' Cell layer thickness: ' num2str(t,3) ' m'];
set(handles.text_geometry, 'String', geo_str);

axes(handles.main_display)
cla
hold(handles.main_display, 'on')
handles = ScalePlot(hObject, handles);
PlotDesign([], rand(6*zu, 1), 0, xu, yu, zu, s, t, 'monotone', 'discrete', [], handles.removal_depth);
handles = PlotAxes(hObject, handles);
handles = DressPlot(hObject, handles, 'on');

guidata(hObject, handles)
function step1_next_Callback(hObject, eventdata, handles)
if ~handles.geometrySet
    errordlg('No geometry settings specified!')
    return
end

handles.step = 2;
handles = UpdateDisplay(hObject, handles);
guidata(hObject, handles)

%% Step 2
function step2_setTwist_Callback(hObject, eventdata, handles)
set(handles.text_twist, 'String', 'No twist(s) specified');

handles.DOFnumvec = [];
handles.twistSet = false;
handles.designSet = false;
set(handles.step2_generateDesign, 'Enable', 'off');
handles.Tmat = [];
guidata(hObject, handles)

Answer = inputdlg({'How many intermediate freedom spaces would you like to use?'}, 'Specify freedom spaces', 1, {num2str(handles.fnum)});
if isempty(Answer); return; end
handles.fnum = str2double(Answer{1});

DOFnumvec = zeros(1,handles.fnum);

options.Resize ='on';
options.WindowStyle='normal';
options.Interpreter='tex';

xu = str2double(handles.geometry{1});
yu = str2double(handles.geometry{2});
zu = str2double(handles.geometry{3});
s = str2double(handles.geometry{4});
t = str2double(handles.geometry{5});
xm = xu/2 * s;
ym = yu/2 * s;

[az, el] = view;

cla
hold(handles.main_display, 'on')
PlotDesign([], rand(6*zu, 1), 0, xu, yu, zu, s, t, 'monotone', 'discrete', [], handles.removal_depth);
handles = PlotAxes(hObject, handles);
handles = DressPlot(hObject, handles, 'on');

for hh = 1:handles.fnum
    
    %     Answer = inputdlg({['How many DOFs constitute freedom space ' num2str(hh) '?']}, '', 1, {'1'}, options);
    %     if isempty(Answer); return; end
    %     X = str2double(Answer{1});
    title_str = ['Select intermediate freedom space #' num2str(hh) ' from yellow region'];
    [DOF, type] = FACTselect(handles.img.FACT, title_str);
    if isempty(DOF)
        cla
        hold(handles.main_display, 'on')
        PlotDesign([], rand(6*zu, 1), 0, xu, yu, zu, s, t, 'monotone', 'discrete', [], handles.removal_depth);
        handles = PlotAxes(hObject, handles);
        handles = DressPlot(hObject, handles, 'on');
        
        errordlg('No valid freedom space selected')
        return
    end
    X = DOF;
    if DOF == 0
        Tmat = [0 0 0 0 0 0];
    end
    
    DOFnumvec(1,hh) = X; %they input this for each intermediate freedom space
    handles.DOFnumvec = DOFnumvec;
    for gg = 1:DOFnumvec(1,hh)
        
        if DOF > 1
            Button = questdlg('Which type of DOF would you like?', 'Specify DOF', 'Translation', 'Rotation', 'Screw', 'Translation');
        elseif DOF == 1
            switch type
                case 1
                    Button = 'Rotation';
                case 2
                    Button = 'Screw';
                case 3
                    Button = 'Translation';
            end
        end
        
        if isempty(Button); return; end
        
        switch Button
            case 'Translation'
                hfig = figure('NumberTitle', 'off', 'Name', 'Translation DOF');
                set(gcf,'color','w');
                set(gcf,'MenuBar','none')
                set(gcf,'ToolBar','none')
                try
                    imshow(handles.img.translation);
                catch
                    image(handles.img.translation)
                    axis equal
                end
                
                prompts = {'Enter a 1x3 vector that points along the line of action of the twist vector (v)'};
                defaults = {'[1 0 0]'};
                Answer = inputdlg(prompts, 'Specify twist (translation)', 1, defaults, options);
                delete(hfig)
                if isempty(Answer);
                    cla
                    hold(handles.main_display, 'on')
                    PlotDesign([], rand(6*zu, 1), 0, xu, yu, zu, s, t, 'monotone', 'discrete', [], handles.removal_depth);
                    handles = PlotAxes(hObject, handles);
                    handles = DressPlot(hObject, handles, 'on');
                    
                    return;
                end
                
                ww = str2num(Answer{1});
                ww = ww/sqrt(dot(ww,ww)); %make it a unit vector
                
                Tmat(gg,1+((hh-1)*6):6+((hh-1)*6))=[0 0 0 ww];
            case 'Rotation'
                hfig = figure('NumberTitle', 'off', 'Name', 'Rotation DOF');
                set(gcf,'color','w');
                set(gcf,'MenuBar','none')
                set(gcf,'ToolBar','none')
                try
                    imshow(handles.img.rotation)
                catch
                    image(handles.img.rotation)
                    axis equal
                end
                
                prompts = {'Enter a 1x3 vector that points from the origin to any location along the line of action of the twist vector (c)', ...
                    'Enter a 1x3 vector that points along the line of action of the twist vector (\omega)'};
                pt_str = ['[' num2str(xm) ' ' num2str(ym) ' 0]'];
                defaults = {pt_str, '[0 0 1]'};
                Answer = inputdlg(prompts, 'Specify twist (rotation)', 1, defaults, options);
                delete(hfig)
                if isempty(Answer);
                    cla
                    hold(handles.main_display, 'on')
                    PlotDesign([], rand(6*zu, 1), 0, xu, yu, zu, s, t, 'monotone', 'discrete', [], handles.removal_depth);
                    handles = PlotAxes(hObject, handles);
                    handles = DressPlot(hObject, handles, 'on');
                    
                    return;
                end
                
                loc = str2num(Answer{1});
                ww = str2num(Answer{2});
                ww = ww/sqrt(dot(ww,ww)); %make it a unit vector
                
                p = 0;
                Tmat(gg,1+((hh-1)*6):6+((hh-1)*6))=[ww, cross(loc,ww)];
            case 'Screw'
                hfig = figure('NumberTitle', 'off', 'Name', 'Screw DOF');
                set(gcf,'color','w');
                set(gcf,'MenuBar','none')
                set(gcf,'ToolBar','none')
                try
                    imshow(handles.img.screw)
                catch
                    image(handles.img.screw)
                    axis equal
                end
                
                prompts = {'Enter a 1x3 vector that points from the origin to any location along the line of action of the twist vector (c)', ...
                    'Enter a 1x3 vector that points along the line of action of the twist vector (\omega)', ...
                    'Enter the pitch of the twist vector (p)'};
                pt_str = ['[' num2str(xm) ' ' num2str(ym) ' 0]'];
                defaults = {pt_str, '[0 0 1]', '1'};
                Answer = inputdlg(prompts, 'Specify twist (screw)', 1, defaults, options);
                delete(hfig)
                if isempty(Answer);
                    cla
                    hold(handles.main_display, 'on')
                    PlotDesign([], rand(6*zu, 1), 0, xu, yu, zu, s, t, 'monotone', 'discrete', [], handles.removal_depth);
                    handles = PlotAxes(hObject, handles);
                    handles = DressPlot(hObject, handles, 'on');
                    
                    return;
                end
                
                loc = str2num(Answer{1});
                ww = str2num(Answer{2});
                ww = ww/sqrt(dot(ww,ww)); %make it a unit vector
                p = str2double(Answer{3});
                
                if p == 0
                    warndlg('Pitch set to zero, specifying rotation...')
                    Tmat(gg,1+((hh-1)*6):6+((hh-1)*6))=[ww, cross(loc,ww)];
                elseif isinf(p)
                    warndlg('Pitch set to zero, specifying translation...')
                    Tmat(gg,1+((hh-1)*6):6+((hh-1)*6))=[0 0 0 ww];
                else
                    Tmat(gg,1+((hh-1)*6):6+((hh-1)*6))=[ww, cross(loc,ww)+(p*ww)];
                end
        end
        
        cla
        hold(handles.main_display, 'on')
        PlotDesign([], rand(6*zu, 1), 0, xu, yu, zu, s, t, 'monotone', 'discrete', [], handles.removal_depth);
        DrawTwist(handles,Tmat);
        handles = PlotAxes(hObject, handles);
        handles = DressPlot(hObject, handles, 'on');
    end
end

handles.DOFnumvec = DOFnumvec;
handles.Tmat = Tmat;
handles.twistSet = true;

str{1,1} = 'Twist set:';
str{2,1} = [' ' num2str(handles.fnum) ' freedom space(s)'];
str{3,1} = [' ' num2str(sum(DOFnumvec)) ' total DOF(s)'];
set(handles.text_twist, 'String', str);

set(handles.step2_generateDesign, 'Enable', 'on');
handles = UpdateInstructions(hObject, handles);
guidata(hObject, handles)
function step2_next_Callback(hObject, eventdata, handles)
if ~handles.twistSet
    errordlg('No twist(s) specified!')
    return
end

if ~handles.designSet
    errordlg('Generate design before proceeding!')
    return
end

handles = UpdateToggles(hObject, handles);

handles.step = 3;
handles = UpdateDisplay(hObject, handles);
guidata(hObject, handles)
function step2_prev_Callback(hObject, eventdata, handles)
handles.step = 1;

xu = str2double(handles.geometry{1});
yu = str2double(handles.geometry{2});
zu = str2double(handles.geometry{3});
s = str2double(handles.geometry{4});
t = str2double(handles.geometry{5});

axes(handles.main_display)
cla
hold(handles.main_display, 'on')
handles = ScalePlot(hObject, handles);
PlotDesign([], rand(6*zu, 1), 0, xu, yu, zu, s, t, 'monotone', 'discrete', [], handles.removal_depth);
handles = PlotAxes(hObject, handles);
handles = DressPlot(hObject, handles, 'on');

handles = UpdateDisplay(hObject, handles);
guidata(hObject, handles)
function [handles, success, bar] = CreateDesign(hObject, handles, resolution)
if nargin < 3 || isempty(resolution)
    resolution = 400;
end

success = false;

E = 200e9;
G = 70e9;
rho = 2700;

xu = str2double(handles.geometry{1});
yu = str2double(handles.geometry{2});
zu = str2double(handles.geometry{3});
s = str2double(handles.geometry{4});
t = str2double(handles.geometry{5});
r = str2double(handles.geometry{6});

DOFnumvec = handles.DOFnumvec;
fnum = handles.fnum;
Tmat = handles.Tmat;

% Calculate the intermediate freedom space's constraint spaces

del=zeros(6,6);
del(1:3,4:6)=eye(3);
del(4:6,1:3)=eye(3);
Cnumvec=6 - DOFnumvec;
for hh=1:fnum
    Wmat((1+((hh-1)*6):6+((hh-1)*6)),1:Cnumvec(1,hh)) = null(Tmat(1:DOFnumvec(1,hh),1+((hh-1)*6):6+((hh-1)*6))*del,'r');
end

% perform unit-cell sweep to identify all the wire flexure constraints
% within each cell in the design.

Constraint = [];
count = 0;
zct = 0;
layer = 0;
xvec = 0 : s : s*(xu-1);
yvec = 0 : s : s*(yu-1);
zvec = -t : -s : -s*zu;
Dropdowns = [];
try
    bar = waitbar(0, 'Computing geometry...');
    set(bar, 'Name', 'Computing geometry')
catch
    bar = [];
end

for z = zvec
    zct = zct+1;
    layer = layer+1;
    for x = xvec
        for y = yvec
            ConstraintThisCell = [];
            
            mode = 'normal';
            side = '+x';
            d = t;
            
            iteration = 0;
            
            % point sweep
            cc = 0;
            Wrench = zeros(1,6);
            
            while cc ~= Cnumvec(1,zct)
                if strcmp(mode, 'dropdown')
                    if ~side_selected
                        switch side
                            case '+x'; side = '-x';
                            case '-x'; side = '+y';
                            case '+y'; side = '-y';
                            case '-y'; side = '+x';
                        end
                    end
                    d = d + t/resolution;
                end
                
                if strcmp(mode, 'normal')
                    R1 = (x+r)+((x+s-r)-(x+r)).*rand;
                    R2 = (y+r)+((y+s-r)-(y+r)).*rand;
                    R3 = z;
                elseif strcmp(mode, 'dropdown')
                    switch side
                        case '+x'
                            R1 = x+s-t;
                            R2 = (y+r)+((y+s-r)-(y+r))*rand;
                        case '-x'
                            R1 = x+t;
                            R2 = (y+r)+((y+s-r)-(y+r))*rand;
                        case '+y'
                            R1 = (x+r)+((x+s-r)-(x+r))*rand;
                            R2 = y+s-t;
                        case '-y'
                            R1 = (x+r)+((x+s-r)-(x+r))*rand;
                            R2 = y+t;
                    end
                    R3 = (z-r) - (d-r)*rand;
                end
                
                for i = 1:Cnumvec(1,zct)
                    FullMat(1,i)=((R2*Wmat(3+((zct-1)*6),i))-(R3*Wmat(2+((zct-1)*6),i))-Wmat(4+((zct-1)*6),i));
                    FullMat(2,i)=((R3*Wmat(1+((zct-1)*6),i))-(R1*Wmat(3+((zct-1)*6),i))-Wmat(5+((zct-1)*6),i));
                    FullMat(3,i)=((R1*Wmat(2+((zct-1)*6),i))-(R2*Wmat(1+((zct-1)*6),i))-Wmat(6+((zct-1)*6),i));
                end
                Cap = null(FullMat);
                [row1, col1] = size(Cap);
                Fmat = Wmat(1+((zct-1)*6):3+((zct-1)*6),:)*Cap;
                Vec = -1+2.*rand(col1,1);
                F = Fmat*Vec;
                
                if strcmp(mode, 'normal')
                    x_conditions = and((R1+((F(1,1)/F(3,1))*(-s+(2*t))))>=(x+r), (R1+((F(1,1)/F(3,1))*(-s+(2*t))))<=(x+s-r));
                    y_conditions = and((R2+((F(2,1)/F(3,1))*(-s+(2*t))))>=(y+r), (R2+((F(2,1)/F(3,1))*(-s+(2*t))))<=(y+s-r));
                    
                    endpos(1) = (R1+((F(1,1)/F(3,1))*(-s+(2*t))));
                    endpos(2) = (R2+((F(2,1)/F(3,1))*(-s+(2*t))));
                    endpos(3) = (R3-s+(2*t));
                    
                    ThisConstraint = [R1 R2 R3 endpos(1) endpos(2) endpos(3) 0];
                    wire_spacing = CheckWireSpacing(ConstraintThisCell, ThisConstraint, 2*r);
                    
                    bool = x_conditions && y_conditions && wire_spacing;
                elseif strcmp(mode, 'dropdown')
                    side_to_side = false;
                    side_to_bottom = false;
                    top_to_side = false;
                    wire_spacing = true;
                    
                    z_top = R3;
                    z_bottom = z - s + t;
                    dz = z_bottom - z_top;
                    
                    switch side
                        case '+x' % Propagate in -x direction
                            x1 = true;
                            x2 = true;
                            y1 = (R2 + F(2,1)/F(1,1)*-(s-2*t)) >= (y+r);
                            y2 = (R2 + F(2,1)/F(1,1)*-(s-2*t)) <= (y+s-r);
                            z1 = (R3 + F(3,1)/F(1,1)*-(s-2*t)) >= (z-s+2*t+r); % Off the floor
                            z2 = (R3 + F(3,1)/F(1,1)*-(s-2*t)) <= (z-s+2*t+d-r); % On the wall
                            side_to_side = x1 && x2 && y1 && y2 && z1 && z2;
                            if side_to_side
                                endpos(1) = R1 - s + 2*t;
                                endpos(2) = R2 + F(2,1)/F(1,1)*-(s-2*t);
                                endpos(3) = R3 + F(3,1)/F(1,1)*-(s-2*t);
                            else
                                xb = and((R1+((F(1,1)/F(3,1))*dz))>=(x+r), (R1+((F(1,1)/F(3,1))*dz))<=(x+s-r));
                                yb = and((R2+((F(2,1)/F(3,1))*dz))>=(y+r), (R2+((F(2,1)/F(3,1))*dz))<=(y+s-r));
                                side_to_bottom = xb && yb;
                                
                                if side_to_bottom
                                    endpos(1) = R1+((F(1,1)/F(3,1))*dz);
                                    endpos(2) = R2+((F(2,1)/F(3,1))*dz);
                                    endpos(3) = z_bottom;
                                else
                                    R1 = (x+r)+((x+s-r)-(x+r)).*rand; % Random point on top surface
                                    R2 = (y+r)+((y+s-r)-(y+r)).*rand;
                                    R3 = z;
                                    
                                    dx = x - R1 + t;
                                    % Propagate in -x direction
                                    x1 = true;
                                    x2 = true;
                                    y1 = (R2 + F(2,1)/F(1,1)*dx) >= (y+r);
                                    y2 = (R2 + F(2,1)/F(1,1)*dx) <= (y+s-r);
                                    z1 = (R3 + F(3,1)/F(1,1)*dx) >= (z-s+2*t+r); % Off the floor
                                    z2 = (R3 + F(3,1)/F(1,1)*dx) <= (z-s+2*t+d-r); % On the wall
                                    
                                    top_to_side = x1 && x2 && y1 && y2 && z1 && z2;
                                    
                                    if top_to_side
                                        endpos(1) = R1 + dx;
                                        endpos(2) = R2 + F(2,1)/F(1,1)*dx;
                                        endpos(3) = R3 + F(3,1)/F(1,1)*dx;
                                    end
                                end
                            end
                            
                        case '-x' % Propagate in +x direction
                            x1 = true;
                            x2 = true;
                            y1 = (R2 + F(2,1)/F(1,1)*(s-2*t)) >= (y+r);
                            y2 = (R2 + F(2,1)/F(1,1)*(s-2*t)) <= (y+s-r);
                            z1 = (R3 + F(3,1)/F(1,1)*(s-2*t)) >= (z-s+2*t+r); % Off the floor
                            z2 = (R3 + F(3,1)/F(1,1)*(s-2*t)) <= (z-s+2*t+d-r); % On the wall
                            side_to_side = x1 && x2 && y1 && y2 && z1 && z2;
                            if side_to_side
                                endpos(1) = R1 + s - 2*t;
                                endpos(2) = R2 + F(2,1)/F(1,1)*(s-2*t);
                                endpos(3) = R3 + F(3,1)/F(1,1)*(s-2*t);
                            else
                                xb = and((R1+((F(1,1)/F(3,1))*dz))>=(x+r), (R1+((F(1,1)/F(3,1))*dz))<=(x+s-r));
                                yb = and((R2+((F(2,1)/F(3,1))*dz))>=(y+r), (R2+((F(2,1)/F(3,1))*dz))<=(y+s-r));
                                side_to_bottom = xb && yb;
                                
                                if side_to_bottom
                                    endpos(1) = R1+((F(1,1)/F(3,1))*dz);
                                    endpos(2) = R2+((F(2,1)/F(3,1))*dz);
                                    endpos(3) = z_bottom;
                                else
                                    R1 = (x+r)+((x+s-r)-(x+r)).*rand; % Random point on top surface
                                    R2 = (y+r)+((y+s-r)-(y+r)).*rand;
                                    R3 = z;
                                    
                                    dx = x + s - R1 - t;
                                    % Propagate in +x direction
                                    x1 = true;
                                    x2 = true;
                                    y1 = (R2 + F(2,1)/F(1,1)*dx) >= (y+r);
                                    y2 = (R2 + F(2,1)/F(1,1)*dx) <= (y+s-r);
                                    z1 = (R3 + F(3,1)/F(1,1)*dx) >= (z-s+2*t+r); % Off the floor
                                    z2 = (R3 + F(3,1)/F(1,1)*dx) <= (z-s+2*t+d-r); % On the wall
                                    
                                    top_to_side = x1 && x2 && y1 && y2 && z1 && z2;
                                    
                                    if top_to_side
                                        endpos(1) = R1 + dx;
                                        endpos(2) = R2 + F(2,1)/F(1,1)*dx;
                                        endpos(3) = R3 + F(3,1)/F(1,1)*dx;
                                    end
                                end
                            end
                            
                        case '+y' % Propagate in -y direction
                            x1 = (R1 + F(1,1)/F(2,1)*-(s-2*t)) >= (x+r);
                            x2 = (R1 + F(1,1)/F(2,1)*-(s-2*t)) <= (x+s-r);
                            y1 = true;
                            y2 = true;
                            z1 = (R3 + F(3,1)/F(2,1)*-(s-2*t)) >= (z-s+2*t+r); % Off the floor
                            z2 = (R3 + F(3,1)/F(2,1)*-(s-2*t)) <= (z-s+2*t+d-r); % On the wall
                            side_to_side = x1 && x2 && y1 && y2 && z1 && z2;
                            if side_to_side
                                endpos(1) = R1 + F(1,1)/F(2,1)*-(s-2*t);
                                endpos(2) = R2 - s + 2*t;
                                endpos(3) = R3 + F(3,1)/F(2,1)*-(s-2*t);
                            else
                                xb = and((R1+((F(1,1)/F(3,1))*dz))>=(x+r), (R1+((F(1,1)/F(3,1))*dz))<=(x+s-r));
                                yb = and((R2+((F(2,1)/F(3,1))*dz))>=(y+r), (R2+((F(2,1)/F(3,1))*dz))<=(y+s-r));
                                side_to_bottom = xb && yb;
                                
                                if side_to_bottom
                                    endpos(1) = R1+((F(1,1)/F(3,1))*dz);
                                    endpos(2) = R2+((F(2,1)/F(3,1))*dz);
                                    endpos(3) = z_bottom;
                                else
                                    R1 = (x+r)+((x+s-r)-(x+r)).*rand; % Random point on top surface
                                    R2 = (y+r)+((y+s-r)-(y+r)).*rand;
                                    R3 = z;
                                    
                                    dy = y - R2 + t;
                                    % Propagate in -y direction
                                    x1 = (R1 + F(1,1)/F(2,1)*dy) >= (x+r);
                                    x2 = (R1 + F(1,1)/F(2,1)*dy) <= (x+s-r);
                                    y1 = true;
                                    y2 = true;
                                    z1 = (R3 + F(3,1)/F(2,1)*dy) >= (z-s+2*t+r); % Off the floor
                                    z2 = (R3 + F(3,1)/F(2,1)*dy) <= (z-s+2*t+d-r); % On the wall
                                    
                                    top_to_side = x1 && x2 && y1 && y2 && z1 && z2;
                                    
                                    if top_to_side
                                        endpos(1) = R1 + F(1,1)/F(2,1)*dy;
                                        endpos(2) = R2 + dy;
                                        endpos(3) = R3 + F(3,1)/F(2,1)*dy;
                                    end
                                end
                            end
                            
                        case '-y' % Propagate in +y direction
                            x1 = (R1 + F(1,1)/F(2,1)*(s-2*t)) >= (x+r);
                            x2 = (R1 + F(1,1)/F(2,1)*(s-2*t)) <= (x+s-r);
                            y1 = true;
                            y2 = true;
                            z1 = (R3 + F(3,1)/F(2,1)*(s-2*t)) >= (z-s+2*t+r); % Off the floor
                            z2 = (R3 + F(3,1)/F(2,1)*(s-2*t)) <= (z-s+2*t+d-r); % On the wall
                            side_to_side = x1 && x2 && y1 && y2 && z1 && z2;
                            if side_to_side
                                endpos(1) = R1 + F(1,1)/F(2,1)*(s-2*t);
                                endpos(2) = R2 + s - 2*t;
                                endpos(3) = R3 + F(3,1)/F(2,1)*(s-2*t);
                            else
                                xb = and((R1+((F(1,1)/F(3,1))*dz))>=(x+r), (R1+((F(1,1)/F(3,1))*dz))<=(x+s-r));
                                yb = and((R2+((F(2,1)/F(3,1))*dz))>=(y+r), (R2+((F(2,1)/F(3,1))*dz))<=(y+s-r));
                                side_to_bottom = xb && yb;
                                
                                if side_to_bottom
                                    endpos(1) = R1+((F(1,1)/F(3,1))*dz);
                                    endpos(2) = R2+((F(2,1)/F(3,1))*dz);
                                    endpos(3) = z_bottom;
                                else
                                    R1 = (x+r)+((x+s-r)-(x+r)).*rand; % Random point on top surface
                                    R2 = (y+r)+((y+s-r)-(y+r)).*rand;
                                    R3 = z;
                                    
                                    dy = y + s - R2 - t;
                                    % Propagate in +y direction
                                    x1 = (R1 + F(1,1)/F(2,1)*dy) >= (x+r);
                                    x2 = (R1 + F(1,1)/F(2,1)*dy) <= (x+s-r);
                                    y1 = true;
                                    y2 = true;
                                    z1 = (R3 + F(3,1)/F(2,1)*dy) >= (z-s+2*t+r); % Off the floor
                                    z2 = (R3 + F(3,1)/F(2,1)*dy) <= (z-s+2*t+d-r); % On the wall
                                    
                                    top_to_side = x1 && x2 && y1 && y2 && z1 && z2;
                                    
                                    if top_to_side
                                        endpos(1) = R1 + F(1,1)/F(2,1)*dy;
                                        endpos(2) = R2 + dy;
                                        endpos(3) = R3 + F(3,1)/F(2,1)*dy;
                                    end
                                end
                            end
                            
                    end
                    
                    ThisConstraint = [R1 R2 R3 endpos(1) endpos(2) endpos(3) 0];
                    wire_spacing = CheckWireSpacing(ConstraintThisCell, ThisConstraint, 2*r);
                    
                    bool = (side_to_side || side_to_bottom || top_to_side) && wire_spacing;
                    if bool
                        side_selected = true;
                    end
                end
                
                if bool
                    cc = cc+1;
                    Wrench(cc,:) = transpose([F; cross([R1; R2; R3], F)]);
                    if cc == 1
                        Constraint(end+1,1:6) = [R1, R2, R3, endpos(1), endpos(2), endpos(3)];
                        Constraint(end,7) = layer;
                        
                        ConstraintThisCell(end+1,:) = Constraint(end,:);
                    else
                        [L, U] = lu(Wrench);
                        if dot(U(cc,:), U(cc,:)) == 0
                            cc = cc-1;
                        else
                            Constraint(end+1,1:6) = [R1, R2, R3, endpos(1), endpos(2), endpos(3)];
                            Constraint(end,7) = layer;
                            
                            ConstraintThisCell(end+1,:) = Constraint(end,:);
                        end
                    end
                end
                iteration = iteration + 1;
                
                if strcmp(mode, 'normal') && iteration > handles.solver.dropdown_threshold
                    mode = 'dropdown';
                    side_selected = false;
                end
                
                if iteration > handles.solver.overall_threshold || d > (2/3*(s-2*t))
                    try close(bar); end
                    
                    return
                end
            end
            if strcmp(mode, 'dropdown')
                xind = x/s + 1;
                yind = y/s + 1;
                zind = find(zvec == z);
                
                Dropdowns(end+1).x = xind;
                Dropdowns(end).y = yind;
                Dropdowns(end).z = zind;
                Dropdowns(end).side = side;
                Dropdowns(end).d = d;
            end
            
            xi = find(xvec == x);
            yi = find(yvec == y);
            zi = find(zvec == z);
            
            n_total = length(xvec) * length(yvec) * length(zvec);
            n_cells = yi + (xi-1)*length(yvec) + (zi-1)*length(xvec)*length(yvec);
            n_ratio = n_cells/n_total;
            
            if xu*yu < 200
                msg = ['Computing geometry for layer ' num2str(zi) ' of ' num2str(length(zvec))];
            else
                msg = ['Computing geometry for cell index (' num2str(xi) ', ' num2str(yi) ', ' num2str(zi) ')'];
            end
            try waitbar(n_ratio, bar, msg); end
        end
    end
    if(zct==fnum)
        zct=0;
    end
end
handles.Dropdowns = Dropdowns;

if nargout == 1
    try close(bar); end
end

% Build the stiffness matrix
C(:,1:3) = Constraint(:,1:3);
C(:,4:6) = Constraint(:,1:3) - Constraint(:,4:6);
clength = sqrt(sum( C(:,4:6).^2, 2));
C(:,4:6) = bsxfun(@rdivide, C(:,4:6), clength);
C(:,10) = clength;
C(:,11) = 2*r;
C(:,13) = E;
C(:,14) = G;
C(:,15) = Constraint(:,7);
C(:,16) = Constraint(:,7) + 1; C(C(:,16) == zu+1,16) = 0;

n = size(C,1);
C(end+1,1:3) = [zu n 0];

K = EulerStiffnessMatrix(C);

%Build the mass matrix
xc = xu/2 * s;
yc = yu/2 * s;
zc = 0:-s:-(zu-1)*s; zc(1) = -t/2;

M = zeros(6*zu, 6*zu);
Nmat = zeros(6*zu, 6*zu);

for k = 1:zu
    L = [xc yc zc(k)]';
    if k == 1
        X = xu * s;
        Y = yu * s;
        Z = t;
        V = X*Y*(zu*s);
    else
        X = xu * s;
        Y = yu * s;
        Z = 2*t;
        V = X*Y*Z;
    end
    Ix = rho*V*(Y^2 + Z^2)/12;
    Iy = rho*V*(X^2 + Z^2)/12;
    Iz = rho*V*(X^2 + Y^2)/12;
    
    In = diag([Ix Iy Iz rho*V rho*V rho*V]);
    n1 = [1 0 0]';
    n2 = [0 1 0]';
    n3 = [0 0 1]';
    n = [n1, n2, n3];
    sub = [cross(L, n1), cross(L, n2), cross(L, n3)];
    N = [n, zeros(3,3); sub, n];
    
    Delta = [zeros(3,3), eye(3); eye(3), zeros(3,3)];
    M_TW = N*Delta*In/N;
    
    inds = (6*k-5):(6*k);
    M(inds, inds) = M_TW;
    Nmat(inds, inds) = N;
end

handles.Constraint = Constraint;
handles.K = K;
handles.M = M;
handles.Nmat = Nmat;

success = true;

guidata(hObject, handles)
function bool = CheckWireSpacing(OtherConstraints, ThisConstraint, d)
if isempty(OtherConstraints)
    bool = true;
else
    subtract = bsxfun(@minus, OtherConstraints(:,1:6), ThisConstraint(:,1:6));
    a_start = subtract(:,1:3).^2;
    d_start = sqrt(sum(a_start,2));
    b_start = d_start >= d;
    
    a_end = subtract(:,4:6).^2;
    d_end = sqrt(sum(a_end,2));
    b_end = d_end >= d;
    
    bool = all(or(b_start, b_end)); % True is pass, false is fail
end
function handles = step2_generateDesign_Callback(hObject, eventdata, handles)
% Create design
tic
handles.Dropdowns = [];
[handles, success, bar] = CreateDesign(hObject, handles, 400);
if ~success
    [handles, success, bar] = CreateDesign(hObject, handles, 2000);
    if ~success
        errordlg('Iteration limit reached - no solution found!')
        return
    end
end
handles.t_computation = toc;

% Plot design
if ~isempty(bar)
    waitbar(1, bar, 'Plotting design...')
end

xu = str2double(handles.geometry{1});
yu = str2double(handles.geometry{2});
zu = str2double(handles.geometry{3});
s = str2double(handles.geometry{4});
t = str2double(handles.geometry{5});

tic
axes(handles.main_display)
cla
hold(handles.main_display, 'on')
handles = ScalePlot(hObject, handles);
PlotDesign(handles.Constraint, rand(6*zu, 1), 0, xu, yu, zu, s, t, 'monotone', 'discrete', handles.Dropdowns, handles.removal_depth);

handles = PlotAxes(hObject, handles);
DrawTwist(handles,handles.Tmat);
handles = DressPlot(hObject, handles, 'on');

handles.t_draw = toc;
try delete(bar); end

% Simulate
[V, D] = eig(handles.M\handles.K);
[handles.D, I] = sort(diag(D),1,'ascend');
V = V(:,I);
handles.V = handles.Nmat\V;

handles.designSet = true;
guidata(hObject, handles)

%% Step 3
function radio_twists_Callback(hObject, eventdata, handles)
handles = UpdateToggles(hObject, handles);
guidata(hObject, handles)
function radio_rainbow_Callback(hObject, eventdata, handles)
handles = UpdateToggles(hObject, handles);
guidata(hObject, handles)
function handles = UpdateToggles(hObject, handles)
xu = str2double(handles.geometry{1});
yu = str2double(handles.geometry{2});
zu = str2double(handles.geometry{3});
s = str2double(handles.geometry{4});
t = str2double(handles.geometry{5});

if get(handles.radio_rainbow,'Value') % Plot rainbow
    plot_colors = 'rainbow';
    
    mode_shape = str2double(get(handles.enter_mode, 'String'));
    [Voi, ~] = ScaleTwist(handles.V(:, mode_shape), s, xu, yu, zu);
    scale = 1e-9;
else % Plot grayscale
    plot_colors = 'monotone';
    Voi = ones(6*zu,1);
    scale = 0;
end

axes(handles.main_display)
cla
hold(handles.main_display, 'on')
set(handles.main_display, 'CLimMode', 'auto')
PlotDesign(handles.Constraint, Voi, scale, xu, yu, zu, s, t, plot_colors, 'discrete', handles.Dropdowns, handles.removal_depth);
if get(handles.radio_twists,'Value') % Plot twist vectors
    handles = PlotAxes(hObject, handles);
    DrawTwist(handles,handles.Tmat);
end

handles = ScalePlot(hObject, handles);
handles = DressPlot(hObject, handles, 'on');
function step3_screenshot_Callback(hObject, eventdata, handles)
handles = DressPlot(hObject, handles, 'off');
cap = getframe(handles.main_display);
handles = DressPlot(hObject, handles, 'on');

image = cap.cdata;
% Fill in background color
I1 = and(and(image(:,:,1)==240, image(:,:,2)==240), image(:,:,3)==240);
I2 = and(and(image(:,:,1)==249, image(:,:,2)==249), image(:,:,3)==249);
I = or(I1, I2);
for k = 1:3
    frame = image(:,:,k);
    frame(I) = uint8(255);
    image(:,:,k) = frame;
end

[filename, pathname] = uiputfile('*.png', 'Save GIF animation as');
if isequal(filename,0) || isequal(pathname,0)
    return
end
fullfile = [pathname filename];

imwrite(image, fullfile, 'png', 'transparency', [1 1 1]);
function step3_animate_Callback(hObject, eventdata, handles, mode_shape, save_file)
[az, el] = view;

profile_mode = false;
if profile_mode; profile on; end

set(handles.step3_cancel, 'Enable', 'on')
set(handles.step3_cancel, 'Value', 0)
set(handles.step3_saveGIF, 'Enable', 'off')
guidata(hObject, handles)

nframes = str2double(get(handles.enter_frames, 'String'));
nscale = 1;
xu = str2double(handles.geometry{1});
yu = str2double(handles.geometry{2});
zu = str2double(handles.geometry{3});
s = str2double(handles.geometry{4});
t = str2double(handles.geometry{5});

if nargin < 4 || isempty(mode_shape)
    mode_shape = str2double(get(handles.enter_mode, 'String'));
end
[Voi, ~] = ScaleTwist(handles.V(:, mode_shape), s, xu, yu, zu);

handles.LastGIF = [];
axes(handles.main_display)
count = 1;

handles = DressPlot(hObject, handles, 'off');

scale_vec = linspace(-1, 1, nframes);
for scale = scale_vec
    
    str = ['Animating frame: ' num2str(find(scale_vec == scale)) ' of ' num2str(length(scale_vec))];
    set(handles.text_instructions, 'String', str);
    
    hold(handles.main_display, 'off')
    del = plot3(0,0,0,'w.');
    delete(del)
    
    hold(handles.main_display, 'on')
    
    if get(handles.radio_rainbow,'Value') % Plot rainbow
        plot_colors = 'rainbow';
    else % Plot grayscale
        plot_colors = 'monotone';
    end
    
    PlotDesign(handles.Constraint, Voi, scale*nscale, xu, yu, zu, s, t, plot_colors, 'discrete', handles.Dropdowns, handles.removal_depth);
    if scale == scale_vec(1)
        c_limits = caxis;
    else
        caxis(c_limits);
    end
    
    if get(handles.radio_twists,'Value') % Plot twist vectors
        handles = PlotAxes(hObject, handles);
        DrawTwist(handles,handles.Tmat);
    end
    
    axis equal
    handles = DressPlot(hObject, handles, 'off');
    handles = ScalePlot(hObject, handles);
    view([az, el])
    %     drawnow
    
    cap = getframe(handles.main_display);
    image = cap.cdata;
    
    handles.LastMap = colorcube(256);
    handles.LastGIF(:,:,1,count) = rgb2ind(image, handles.LastMap, handles.dithermode);
    
    set(handles.enter_frames, 'String', num2str(count))
    
    if get(handles.step3_cancel, 'Value') == 1
        set(handles.step3_cancel, 'Value', 0)
        guidata(hObject, handles)
        return
    end
    
    count = count + 1;
end
% Fill in background color
I_beige = rgb2ind(image(1,1,:), handles.LastMap, handles.dithermode);
I_white = rgb2ind(ones(1,1,3), handles.LastMap, handles.dithermode);
for k = 1:size(handles.LastGIF,4)
    frame = handles.LastGIF(:,:,1,k);
    frame(frame == I_beige) = I_white;
    handles.LastGIF(:,:,1,k) = frame;
end

% Finish
set(handles.step3_cancel, 'Enable', 'off')
set(handles.step3_cancel, 'Value', 0)
handles = DressPlot(hObject, handles, 'on');
set(handles.step3_saveGIF, 'Enable', 'on')

if nargin < 5 || isempty(save_file)
    Button = questdlg('Would you like to save a .gif file?', 'Save animation', 'Yes', 'No', 'Yes');
else
    Button = 'Yes';
end

switch Button
    case 'Yes'
        handles = step3_saveGIF_Callback(hObject, eventdata, handles);
end
handles = UpdateDisplay(hObject, handles);
guidata(hObject, handles)

if profile_mode; profile viewer; end
function handles = step3_saveGIF_Callback(hObject, eventdata, handles, save_file)
if nargin < 4 || isempty(save_file)
    [filename, pathname] = uiputfile('*.gif', 'Save GIF animation as');
    if isequal(filename,0) || isequal(pathname,0)
        return
    end
    
    prompts = {'Delay time between frames (sec)', 'Loop count', 'Animate cyclically? (bool)', 'Open once saved? (bool)'};
    defaults = {num2str(handles.GIF.delay), num2str(handles.GIF.loopCount), '1', '1'};
    Answer = inputdlg(prompts,'Write GIF animation',1,defaults);
    if isempty(Answer); return; end
    handles.GIF.delay = str2double(Answer{1});
    handles.GIF.loopCount = str2double(Answer{2});
    bidirectional = str2double(Answer{3});
    open_bool = str2double(Answer{4});
    
else
    pathname = [];
    filename = save_file;
    
    handles.GIF.delay = 0.1;
    handles.GIF.loopCount = inf;
    bidirectional = 1;
    open_bool = 0;
end

if bidirectional
    forward = handles.LastGIF(:,:,:,1:end-1);
    backward = handles.LastGIF(:,:,:,end:-1:2);
    WriteGIF = cat(4, forward, backward);
else
    WriteGIF = handles.LastGIF;
end

imwrite(WriteGIF+1, handles.LastMap, fullfile(pathname, filename), 'DelayTime', handles.GIF.delay, 'LoopCount', handles.GIF.loopCount)

if open_bool
    winopen(fullfile(pathname, filename));
end

guidata(hObject, handles)
function step3_prev_Callback(hObject, eventdata, handles)
xu = str2double(handles.geometry{1});
yu = str2double(handles.geometry{2});
zu = str2double(handles.geometry{3});
s = str2double(handles.geometry{4});
t = str2double(handles.geometry{5});

axes(handles.main_display)
cla
hold(handles.main_display, 'on')
PlotDesign(handles.Constraint, rand(6*zu, 1), 0, xu, yu, zu, s, t, 'monotone', 'discrete', handles.Dropdowns, handles.removal_depth);
handles = PlotAxes(hObject, handles);
DrawTwist(handles,handles.Tmat);

handles = ScalePlot(hObject, handles);
handles = DressPlot(hObject, handles, 'on');

handles.step = 2;
handles = UpdateDisplay(hObject, handles);
guidata(hObject, handles)
function enter_frames_Callback(hObject, eventdata, handles)
n = str2double(get(handles.enter_frames,'String'));
function enter_frames_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function step3_cancel_Callback(hObject, eventdata, handles)
function enter_mode_Callback(hObject, eventdata, handles)
handles = UpdateToggles(hObject, handles);
guidata(hObject, handles)
function enter_mode_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function mode_minus_Callback(hObject, eventdata, handles)
value = str2double(get(handles.enter_mode, 'String'));
if value > 1
    value = value - 1;
end
set(handles.enter_mode, 'String', num2str(value))

handles = UpdateToggles(hObject, handles);
guidata(hObject, handles)
function mode_plus_Callback(hObject, eventdata, handles)
zu = str2double(handles.geometry{3});
value = str2double(get(handles.enter_mode, 'String'));
if value < zu*6
    value = value + 1;
end
set(handles.enter_mode, 'String', num2str(value))

handles = UpdateToggles(hObject, handles);
guidata(hObject, handles)

%% Import/export designs
function design_load_Callback(hObject, eventdata, handles)
[filename, pathname] = uigetfile('*.mat', 'Load design file');
if isequal(filename,0) || isequal(pathname,0)
    return;
end

try
    data = load([pathname filename]);
    handles.geometry{1} = data.topology.xu;
    handles.geometry{2} = data.topology.yu;
    handles.geometry{3} = data.topology.zu;
    handles.geometry{4} = data.topology.s;
    handles.geometry{5} = data.topology.t;
    handles.geometry{6} = data.topology.r;
    handles.Constraint = data.topology.Constraint;
    handles.Dropdowns = data.topology.Dropdowns;
    handles.Tmat = data.twist.mat;
    handles.DOFnumvec = data.twist.DOFnumvec;
    handles.K = data.statespace.K;
    handles.M = data.statespace.M;
    handles.V = data.statespace.V;
    
    handles.step = 3;
    handles = UpdateDisplay(hObject, handles);
    handles = UpdateToggles(hObject, handles);
catch ME
    errordlg('Error loading data - ensure data is in the correct format and try again')
end

guidata(hObject, handles)
function design_save_Callback(hObject, eventdata, handles)
topology.xu = handles.geometry{1};
topology.yu = handles.geometry{2};
topology.zu = handles.geometry{3};
topology.s = handles.geometry{4};
topology.t = handles.geometry{5};
topology.r = handles.geometry{6};
topology.Constraint = handles.Constraint;
topology.Dropdowns = handles.Dropdowns;
twist.mat = handles.Tmat;
twist.DOFnumvec = handles.DOFnumvec;
statespace.K = handles.K;
statespace.M = handles.M;
statespace.V = handles.V;
savetime = datestr(now,'mm-dd-yy_HH-MM');

[filename, pathname] = uiputfile('*.mat', 'Save design file');
if isequal(filename,0) || isequal(pathname,0)
    return;
end
save([pathname filename], 'topology', 'statespace', 'twist', 'savetime');

%% Plot tools
function figure1_KeyPressFcn(hObject, eventdata, handles)
key = eventdata.Key;
modifier = eventdata.Modifier;
if strcmp(key,'e') & strcmp(modifier,'control')
    set(handles.radio_rainbow,'Value',1)
    set(handles.enter_frames,'String','9');
    
    xu = str2double(handles.geometry{1});
    yu = str2double(handles.geometry{2});
    zu = str2double(handles.geometry{3});
    
    Answer = inputdlg({'DOFs to export'},'Batch animation export', 1, {'[1 2 3]'});
    if isempty(Answer); return; end
    modes = str2num(Answer{1});
    
    for k = modes
        tic
        disp(['Exporting DOF: ' num2str(k)])
        mode_shape = k;
        save_file = [num2str(xu) 'x' num2str(yu) 'x' num2str(zu) '_mode' num2str(mode_shape) '.gif'];
        step3_animate_Callback(hObject, eventdata, handles, mode_shape, save_file);
        toc
    end
elseif strcmp(key,'q') & strcmp(modifier,'control')
    Button = questdlg('Shutdown after computing?','Shutdown','Yes','No','No');
    
    Answer = inputdlg({'DOFs to export'},'Batch animation export', 1, {'[1 2 3]'});
    if isempty(Answer); return; end
    modes = str2num(Answer{1});
    
    handles = step2_generateDesign_Callback(hObject, eventdata, handles);
    
    set(handles.radio_rainbow,'Value',1)
    set(handles.enter_frames,'String','9');
    
    xu = str2double(handles.geometry{1});
    yu = str2double(handles.geometry{2});
    zu = str2double(handles.geometry{3});
    s = str2double(handles.geometry{4});
    t = str2double(handles.geometry{5});
    
    save_file = [num2str(xu) 'x' num2str(yu) 'x' num2str(zu) '_mode.mat'];
    t_computation = handles.t_computation;
    t_draw = handles.t_draw;
    savetime = clock;
    computer = getenv('username');
    Tmat = handles.Tmat;
    save(save_file,'t_computation','t_draw','savetime','computer','xu','yu','zu','s','t','Tmat')
    
    prev_removal_depth = handles.removal_depth;
    for k = modes
        tic
        disp(['Exporting DOF: ' num2str(k)])
        mode_shape = k;
        save_file = [num2str(xu) 'x' num2str(yu) 'x' num2str(zu) '_mode' num2str(mode_shape) '.gif'];
        step3_animate_Callback(hObject, eventdata, handles, mode_shape, save_file);
        toc
    end
    handles.removal_depth = prev_removal_depth;
    guidata(hObject, handles)
    
    if strcmp(Button, 'Yes')
        shutdown(2);
    end
elseif strcmp(key,'p') & strcmp(modifier,'control')
    step3_screenshot_Callback(hObject, eventdata, handles);
end
function handles = DressPlot(hObject, handles, mode)
switch mode
    case 'on'
        xu = str2double(handles.geometry{1});
        yu = str2double(handles.geometry{2});
        zu = str2double(handles.geometry{3});
        s = str2double(handles.geometry{4});
        
        try
            set(handles.main_display.XRuler,'Visible',mode);
            set(handles.main_display.YRuler,'Visible',mode);
            set(handles.main_display.ZRuler,'Visible',mode);
        catch
            set(handles.main_display,'XColor','k')
            set(handles.main_display,'YColor','k')
            set(handles.main_display,'ZColor','k')
        end
        xtickvec = 0:s:xu*s;
        ytickvec = 0:s:yu*s;
        ztickvec = -zu*s:s:0;
        tick_labels_to_show = handles.tick_labels_to_show;
        if length(xtickvec) > tick_labels_to_show; xtickvec = 0.1*round(10*linspace(0, xu*s, tick_labels_to_show)); end
        if length(ytickvec) > tick_labels_to_show; ytickvec = 0.1*round(10*linspace(0, yu*s, tick_labels_to_show)); end
        if length(ztickvec) > tick_labels_to_show; ztickvec = 0.1*round(10*linspace(-zu*s, 0, tick_labels_to_show)); end
        set(handles.main_display,'XTick',xtickvec)
        set(handles.main_display,'YTick',ytickvec)
        set(handles.main_display,'ZTick',ztickvec)
        set(handles.main_display,'XGrid',mode)
        set(handles.main_display,'YGrid',mode)
        set(handles.main_display,'ZGrid',mode)
        xlabel('X [m]')
        ylabel('Y [m]')
        zlabel('Z [m]')
    case 'off'
        try
            set(handles.main_display.XRuler,'Visible',mode);
            set(handles.main_display.YRuler,'Visible',mode);
            set(handles.main_display.ZRuler,'Visible',mode);
        catch
            set(handles.main_display,'XColor','w')
            set(handles.main_display,'YColor','w')
            set(handles.main_display,'ZColor','w')
        end
        set(handles.main_display,'Box',mode)
        set(handles.main_display,'XTick',[])
        set(handles.main_display,'YTick',[])
        set(handles.main_display,'ZTick',[])
        set(handles.main_display,'XGrid',mode)
        set(handles.main_display,'YGrid',mode)
        set(handles.main_display,'ZGrid',mode)
        xlabel([])
        ylabel([])
        zlabel([])
end
guidata(hObject, handles)
function handles = ScalePlot(hObject, handles)
xu = str2double(handles.geometry{1});
yu = str2double(handles.geometry{2});
zu = str2double(handles.geometry{3});
s = str2double(handles.geometry{4});

overfill = max([xu yu zu])/3;

set(handles.main_display, 'XlimMode', 'manual')
set(handles.main_display, 'YlimMode', 'manual')
set(handles.main_display, 'ZlimMode', 'manual')
xlim([-s*overfill (xu+overfill)*s])
ylim([-s*overfill (yu+overfill)*s])
zlim([-(zu+1*overfill)*s s*overfill])

guidata(hObject, handles)
function handles = PlotAxes(hObject, handles)
s = str2double(handles.geometry{4});

% axes(handles.main_display)
% DrawLine(0,0,0,s/2,0,0,'X',[0 0 0],1); hold on;
% DrawLine(0,0,0,0,s/2,0,'Y',[0 0 0],1);
% DrawLine(0,0,0,0,0,s/2,'Z',[0 0 0],1);

LW = 1;
plot3([0 s],[0 0],[0 0], 'k', 'LineWidth', LW); hold on;
plot3([0 0],[0 s],[0 0], 'k', 'LineWidth', LW)
plot3([0 0],[0 0],[0 s], 'k', 'LineWidth', LW)

tx = text(s*1.2, 0, 0.2*s, 'X');
set(tx,'HorizontalAlignment','center');

ty = text(0, s*1.2, 0.2*s, 'Y');
set(ty,'HorizontalAlignment','center');

tz = text(0, 0, s*1.2, 'Z');
set(tz,'HorizontalAlignment','center');

handles = DressPlot(hObject, handles, 'on');
handles = ScalePlot(hObject, handles);
guidata(hObject, handles)
function q = DrawLineWithArrow(x,y,z,u,v,w, str, color, LW)
xt = x + u;
yt = y + v;
zt = z + w;

q = quiver3(x,y,z,u,v,w);
set(q,'color',color);
set(q,'LineWidth',LW);
set(q,'MaxHeadSize',1)

if ~isempty(str)
    t = text(xt + (xt-x)*0.3, yt + (yt-y)*0.3, zt + (zt-z)*0.3, str);
    set(t,'HorizontalAlignment','center');
end
function out = rangeA(in)
out = max(in) - min(in);
function l = DrawLine(x,y,z,u,v,w, str, color, LW)
xl = rangeA(get(gca,'Xlim'));
yl = rangeA(get(gca,'Ylim'));
zl = rangeA(get(gca,'Zlim'));
lim = max([xl yl zl]);

m = max([u v w]);
u = u/m*lim*2;
v = v/m*lim*2;
w = w/m*lim*2;

X = [x-u, x+u];
Y = [y-v, y+v];
Z = [z-w, z+w];

l = line(X,Y,Z,'color',color,'LineWidth',LW);

if ~isempty(str)
    t = text(xt + (xt-x)*0.3, yt + (yt-y)*0.3, zt + (zt-z)*0.3, str);
    set(t,'HorizontalAlignment','center');
end
function DrawTwist(handles,T)
xu = str2double(handles.geometry{1});
yu = str2double(handles.geometry{2});
zu = str2double(handles.geometry{3});
s = str2double(handles.geometry{4});
n_intermediates = size(T,2)/6;
count = 1;
for i = 1:n_intermediates
    for k = 1:size(T,1)
        twist = T(k,(6*i-5):6*i);
        if all(twist == 0); continue; end
        [c, w, p] = DecomposePlucker(twist);
        
        if ~all(w==0)
            w = w/norm(w) * s;
        end
        
        mc = min([xu yu zu])/2; % min cells over 2
        
        total = sum(handles.DOFnumvec);
        LW = 2*(2-count/total) - 1;

        if p == 0 % Rotation
            DrawLine(c(1),c(2),c(3),w(1),w(2),w(3),[],[1 0 0],LW);
        elseif isinf(p) % Translation
            DrawLineWithArrow(xu*s/2,yu*s/2,0,w(1)*mc,w(2)*mc,w(3)*mc,[],[0 0 0],3);
        else % Screw
            DrawLine(c(1),c(2),c(3),w(1),w(2),w(3),[],[0 0.5 0],LW);
        end
        count = count + 1;
    end
end
function color = ScaledColor(patch_mat)
color = sqrt( patch_mat(1,:).^2 + patch_mat(2,:).^2 + patch_mat(3,:).^2 );
function [] = PlotDesign(Constraint, T, scale, xu, yu, zu, s, t, colormode, stagedrawmode, Dropdowns, removal_depth)

if scale == 0
    scale = 1e-9;
end

n = EstimatePatches(xu, yu, zu, Dropdowns);

pstruct.x = zeros(4,n);
pstruct.y = zeros(4,n);
pstruct.z = zeros(4,n);
switch colormode
    case 'rainbow'
        pstruct.c = zeros(4,n);
end
pstruct.n = 1;

% monotone
color = [0.8 0.8 0.8];

xc = xu/2 * s;
yc = yu/2 * s;
zc = 0:-s:-(zu-1)*s; zc(1) = -t/2;
zc(end+1) = -zu*s;

Theta = cell(zu,1);
Delta = cell(zu,1);

for k = 1:zu
    inds = (6*k-5):(6*k);
    Tk = T(inds,:) * scale;
    
    theta = Tk(1:3,:);
    R = Rotation(theta(1), theta(2), theta(3));
    Theta{k} = R;
    
    delta = Tk(4:6,:);
    Delta{k} = delta;
end
Theta{end+1} = eye(3);
Delta{end+1} = zeros(3,1);

%% For each layer
for k = 1:zu % For each layer
    L = [xc yc zc(k)]';
    
    if k == 1
        tl = t;
    else
        tl = 2*t;
    end
    
    % Upper and lower surfaces, centered about the origin
    su = [-s*xu/2, -s*xu/2, s*xu/2, s*xu/2; -s*yu/2, s*yu/2, s*yu/2, -s*yu/2; tl/2, tl/2, tl/2, tl/2];
    sl = [-s*xu/2, -s*xu/2, s*xu/2, s*xu/2; -s*yu/2, s*yu/2, s*yu/2, -s*yu/2; -tl/2, -tl/2, -tl/2, -tl/2];
    
    % Rotate the surfaces by the amount specified by the twist vector
    R = Theta{k};
    suR = R*su;
    slR = R*sl;
    
    % Translate the surfaces by the amount specified by the twist vector
    delta = Delta{k};
    
    suT = bsxfun(@plus, suR, delta);
    slT = bsxfun(@plus, slR, delta);
    
    % Move the surfaces to their real position in the material
    su = bsxfun(@plus, suT, L);
    sl = bsxfun(@plus, slT, L);
    
    %% Path the surfaces
    switch stagedrawmode
        case 'discrete'
            xvec = -(xu/2-0.5):(xu/2-0.5);
            yvec = -(yu/2-0.5):(yu/2-0.5);
            for xi = xvec
                for yi = yvec
                    
                    su = [-s, -s, s, s; -s, s, s, -s; tl, tl, tl, tl]/2;
                    su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                    sl = [-s, -s, s, s; -s, s, s, -s; -tl, -tl, -tl, -tl]/2;
                    sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                    
                    Bu = bsxfun(@plus, R*su, delta + L);
                    Bl = bsxfun(@plus, R*sl, delta + L);
                    
                    switch colormode
                        case 'rainbow'
                            Cu = bsxfun(@plus, R*su, delta)-su;
                            Cl = bsxfun(@plus, R*sl, delta)-sl;
                            
                            pstruct = patch_add(pstruct, Bu(1,:), Bu(2,:), Bu(3,:), ScaledColor(Cu));
                            pstruct = patch_add(pstruct, Bl(1,:), Bl(2,:), Bl(3,:), ScaledColor(Cl));
                        case 'monotone'
                            pstruct = patch_add(pstruct, Bu(1,:), Bu(2,:), Bu(3,:));
                            pstruct = patch_add(pstruct, Bl(1,:), Bl(2,:), Bl(3,:));
                    end
                    
                    for side = 1:4
                        if and(abs(xi) ~= (xu/2-0.5), abs(yi) ~= (yu/2-0.5))
                            continue
                        end
                        i1 = side;
                        i2 = mod(side,4) + 1;
                        
                        if k ~= 1
                            Bm = (Bu + Bl)/2;
                            
                            x1 = [Bu(1,i1) Bu(1, i2) Bm(1,i2) Bm(1,i1)];
                            y1 = [Bu(2,i1) Bu(2, i2) Bm(2,i2) Bm(2,i1)];
                            z1 = [Bu(3,i1) Bu(3, i2) Bm(3,i2) Bm(3,i1)];
                            
                            x2 = [Bm(1,i1) Bm(1, i2) Bl(1,i2) Bl(1,i1)];
                            y2 = [Bm(2,i1) Bm(2, i2) Bl(2,i2) Bl(2,i1)];
                            z2 = [Bm(3,i1) Bm(3, i2) Bl(3,i2) Bl(3,i1)];
                            
                            switch colormode
                                case 'rainbow'
                                    Cs = [Cu(:,i1) Cu(:, i2) Cl(:,i2) Cl(:,i1)];
                                    pstruct = patch_add(pstruct, x1, y1, z1, ScaledColor(Cs));
                                    pstruct = patch_add(pstruct, x2, y2, z2, ScaledColor(Cs));
                                case 'monotone'
                                    pstruct = patch_add(pstruct, x1, y1, z1);
                                    pstruct = patch_add(pstruct, x2, y2, z2);
                            end
                            
                        else
                            x = [Bu(1,i1) Bu(1, i2) Bl(1,i2) Bl(1,i1)];
                            y = [Bu(2,i1) Bu(2, i2) Bl(2,i2) Bl(2,i1)];
                            z = [Bu(3,i1) Bu(3, i2) Bl(3,i2) Bl(3,i1)];
                            
                            switch colormode
                                case 'rainbow'
                                    Cs = [Cu(:,i1) Cu(:, i2) Cl(:,i2) Cl(:,i1)];
                                    pstruct = patch_add(pstruct, x, y, z, ScaledColor(Cs));
                                case 'monotone'
                                    pstruct = patch_add(pstruct, x, y, z);
                            end
                        end
                    end
                    
                    %% For the dropdowns
                    if nargin >= 11 && ~isempty(Dropdowns)
                        
                        layer_above = k-1;
                        if layer_above == 0; layer_above = -1; end
                        layer_below = k;
                        
                        xindex = find(xvec == xi);
                        yindex = find(yvec == yi);
                        
                        for di = 1:length(Dropdowns)
                            if roundto(Dropdowns(di).x,3) == xindex
                                if roundto(Dropdowns(di).y,3) == yindex
                                    d = Dropdowns(di).d;
                                    if Dropdowns(di).z == layer_below
                                        switch Dropdowns(di).side
                                            case '+x'
                                                sl = [s/2, s/2, s/2-t, s/2-t; -s/2, s/2, s/2, -s/2; -tl/2-d -tl/2-d -tl/2-d -tl/2-d];
                                                sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                                
                                                % For coordinates only
                                                su = [s/2, s/2, s/2-t, s/2-t; -s/2, s/2, s/2, -s/2; -tl/2 -tl/2 -tl/2 -tl/2];
                                                su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                            case '-x' % VERIFIED
                                                sl = [-s/2, -s/2, -s/2+t, -s/2+t; -s/2, s/2, s/2, -s/2; -tl/2-d -tl/2-d -tl/2-d -tl/2-d];
                                                sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                                
                                                % For coordinates only
                                                su = [-s/2, -s/2, -s/2+t, -s/2+t; -s/2, s/2, s/2, -s/2; -tl/2 -tl/2 -tl/2 -tl/2];
                                                su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                            case '+y'
                                                sl = [-s/2, s/2, s/2, -s/2; s/2, s/2, s/2-t, s/2-t; -tl/2-d -tl/2-d -tl/2-d -tl/2-d];
                                                sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                                
                                                % For coordinates only
                                                su = [-s/2, s/2, s/2, -s/2; s/2, s/2, s/2-t, s/2-t; -tl/2 -tl/2 -tl/2 -tl/2];
                                                su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                            case '-y'
                                                sl = [-s/2, s/2, s/2, -s/2; -s/2, -s/2, -s/2+t, -s/2+t; -tl/2-d -tl/2-d -tl/2-d -tl/2-d];
                                                sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                                
                                                % For coordinates only
                                                su = [-s/2, s/2, s/2, -s/2; -s/2, -s/2, -s/2+t, -s/2+t; -tl/2 -tl/2 -tl/2 -tl/2];
                                                su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                        end
                                    elseif Dropdowns(di).z == layer_above
                                        switch Dropdowns(di).side
                                            case '+x'
                                                sl = [-s/2, -s/2, -s/2+t, -s/2+t; -s/2, s/2, s/2, -s/2; tl/2 tl/2 tl/2 tl/2];
                                                sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                                
                                                su = [-s/2, -s/2, -s/2+t, -s/2+t; -s/2, s/2, s/2, -s/2; tl/2+d tl/2+d tl/2+d tl/2+d];
                                                su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                            case '-x'
                                                % For coordinates only
                                                sl = [s/2, s/2, s/2-t, s/2-t; -s/2, s/2, s/2, -s/2; tl/2 tl/2 tl/2 tl/2];
                                                sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                                
                                                su = [s/2, s/2, s/2-t, s/2-t; -s/2, s/2, s/2, -s/2; tl/2+d tl/2+d tl/2+d tl/2+d];
                                                su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                            case '+y'
                                                sl = [-s/2, s/2, s/2, -s/2; -s/2, -s/2, -s/2+t, -s/2+t; tl/2 tl/2 tl/2 tl/2];
                                                sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                                
                                                su = [-s/2, s/2, s/2, -s/2; -s/2, -s/2, -s/2+t, -s/2+t; tl/2+d tl/2+d tl/2+d tl/2+d];
                                                su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                            case '-y'
                                                sl = [-s/2, s/2, s/2, -s/2; s/2, s/2, s/2-t, s/2-t; tl/2 tl/2 tl/2 tl/2];
                                                sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                                
                                                su = [-s/2, s/2, s/2, -s/2; s/2, s/2, s/2-t, s/2-t; tl/2+d tl/2+d tl/2+d tl/2+d];
                                                su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                        end
                                    else
                                        continue
                                    end
                                    
                                    Bl = bsxfun(@plus, R*sl, delta + L);
                                    Bu = bsxfun(@plus, R*su, delta + L);
                                    
                                    Cl = bsxfun(@plus, R*sl, delta) - sl;
                                    Cu = bsxfun(@plus, R*su, delta) - su;
                                    
                                    switch colormode
                                        case 'rainbow'
                                            pstruct = patch_add(pstruct, Bl(1,:), Bl(2,:), Bl(3,:), ScaledColor(Cl));
                                            pstruct = patch_add(pstruct, Bu(1,:), Bu(2,:), Bu(3,:), ScaledColor(Cu));
                                        case 'monotone'
                                            pstruct = patch_add(pstruct, Bl(1,:), Bl(2,:), Bl(3,:));
                                            pstruct = patch_add(pstruct, Bu(1,:), Bu(2,:), Bu(3,:));
                                    end
                                    
                                    for side = 1:4
                                        i1 = side;
                                        i2 = mod(side,4) + 1;
                                        
                                        x = [Bu(1,i1) Bu(1, i2) Bl(1,i2) Bl(1,i1)];
                                        y = [Bu(2,i1) Bu(2, i2) Bl(2,i2) Bl(2,i1)];
                                        z = [Bu(3,i1) Bu(3, i2) Bl(3,i2) Bl(3,i1)];
                                        Cs = [Cu(:,i1) Cu(:, i2) Cl(:,i2) Cl(:,i1)];
                                        
                                        switch colormode
                                            case 'rainbow'
                                                pstruct = patch_add(pstruct, x, y, z, ScaledColor(Cs));
                                            case 'monotone'
                                                pstruct = patch_add(pstruct, x, y, z);
                                        end
                                    end
                                    
                                end
                            end
                        end
                    end
                end
            end
        case 'continuous'
            pstruct = patch_add(pstruct, su(1,:), su(2,:), su(3,:), color);
            pstruct = patch_add(pstruct, sl(1,:), sl(2,:), sl(3,:), color);
            for side = 1:4
                i1 = side;
                i2 = mod(side,4) + 1;
                x = [su(1,i1) su(1, i2) sl(1,i2) sl(1,i1)];
                y = [su(2,i1) su(2, i2) sl(2,i2) sl(2,i1)];
                z = [su(3,i1) su(3, i2) sl(3,i2) sl(3,i1)];
                pstruct = patch_add(pstruct, x, y, z, color);
            end
    end
end

%% For the grounded stage
tl = t;
su = [-s*xu/2, -s*xu/2, s*xu/2, s*xu/2; -s*yu/2, s*yu/2, s*yu/2, -s*yu/2; tl/2, tl/2, tl/2, tl/2];
sl = [-s*xu/2, -s*xu/2, s*xu/2, s*xu/2; -s*yu/2, s*yu/2, s*yu/2, -s*yu/2; -tl/2, -tl/2, -tl/2, -tl/2];

Lg = [xc yc -zu*s+t/2]';
su = bsxfun(@plus, su, Lg);
sl = bsxfun(@plus, sl, Lg);

switch stagedrawmode
    case 'discrete'
        xvec = -(xu/2-0.5):(xu/2-0.5);
        yvec = -(yu/2-0.5):(yu/2-0.5);
        for xi = xvec
            for yi = yvec
                su = [-s, -s, s, s; -s, s, s, -s; tl, tl, tl, tl]/2;
                su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                sl = [-s, -s, s, s; -s, s, s, -s; -tl, -tl, -tl, -tl]/2;
                sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                
                Bu = bsxfun(@plus, su, Lg);
                Bl = bsxfun(@plus, sl, Lg);
                
                switch colormode
                    case 'rainbow'
                        pstruct = patch_add(pstruct, Bu(1,:), Bu(2,:), Bu(3,:), ScaledColor([0; 0; 0]));
                        pstruct = patch_add(pstruct, Bl(1,:), Bl(2,:), Bl(3,:), ScaledColor([0; 0; 0]));
                    case 'monotone'
                        pstruct = patch_add(pstruct, Bu(1,:), Bu(2,:), Bu(3,:));
                        pstruct = patch_add(pstruct, Bl(1,:), Bl(2,:), Bl(3,:));
                end
                
                for side = 1:4
                    if and(abs(xi) ~= (xu/2-0.5), abs(yi) ~= (yu/2-0.5))
                        continue
                    end
                    i1 = side;
                    i2 = mod(side,4) + 1;
                    x = [Bu(1,i1) Bu(1, i2) Bl(1,i2) Bl(1,i1)];
                    y = [Bu(2,i1) Bu(2, i2) Bl(2,i2) Bl(2,i1)];
                    z = [Bu(3,i1) Bu(3, i2) Bl(3,i2) Bl(3,i1)];
                    switch colormode
                        case 'rainbow'
                            pstruct = patch_add(pstruct, x, y, z, ScaledColor([0; 0; 0]));
                        case 'monotone'
                            pstruct = patch_add(pstruct, x, y, z);
                    end
                end
                
                %% For the dropdowns
                if ~isempty(Dropdowns)
                    
                    xindex = find(xvec == xi);
                    yindex = find(yvec == yi);
                    
                    for di = 1:length(Dropdowns)
                        if roundto(Dropdowns(di).x,3) == xindex
                            if roundto(Dropdowns(di).y,3) == yindex
                                d = Dropdowns(di).d;
                                if Dropdowns(di).z == zu
                                    switch Dropdowns(di).side
                                        case '+x'
                                            sl = [-s/2, -s/2, -s/2+t, -s/2+t; -s/2, s/2, s/2, -s/2; tl tl tl tl];
                                            sl(3,:) = sl(3,:) - s;
                                            sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                            
                                            su = [-s/2, -s/2, -s/2+t, -s/2+t; -s/2, s/2, s/2, -s/2; tl+d tl+d tl+d tl+d];
                                            su(3,:) = su(3,:) - s;
                                            su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                        case '-x'
                                            % For coordinates only
                                            sl = [s/2, s/2, s/2-t, s/2-t; -s/2, s/2, s/2, -s/2; tl tl tl tl];
                                            sl(3,:) = sl(3,:) - s;
                                            sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                            
                                            su = [s/2, s/2, s/2-t, s/2-t; -s/2, s/2, s/2, -s/2; tl+d tl+d tl+d tl+d];
                                            su(3,:) = su(3,:) - s;
                                            su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                        case '+y'
                                            sl = [-s/2, s/2, s/2, -s/2; -s/2, -s/2, -s/2+t, -s/2+t; tl tl tl tl];
                                            sl(3,:) = sl(3,:) - s;
                                            sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                            
                                            su = [-s/2, s/2, s/2, -s/2; -s/2, -s/2, -s/2+t, -s/2+t; tl+d tl+d tl+d tl+d];
                                            su(3,:) = su(3,:) - s;
                                            su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                        case '-y'
                                            sl = [-s/2, s/2, s/2, -s/2; s/2, s/2, s/2-t, s/2-t; tl tl tl tl];
                                            sl(3,:) = sl(3,:) - s;
                                            sl = bsxfun(@plus, sl, [xi*s, yi*s, 0]');
                                            
                                            su = [-s/2, s/2, s/2, -s/2; s/2, s/2, s/2-t, s/2-t; tl+d tl+d tl+d tl+d];
                                            su(3,:) = su(3,:) - s;
                                            su = bsxfun(@plus, su, [xi*s, yi*s, 0]');
                                    end
                                else
                                    continue
                                end
                                
                                Bl = bsxfun(@plus, sl, L);
                                Bu = bsxfun(@plus, su, L);
                                
                                switch colormode
                                    case 'rainbow'
                                        pstruct = patch_add(pstruct, Bl(1,:), Bl(2,:), Bl(3,:), [0 0 0 0]);
                                        pstruct = patch_add(pstruct, Bu(1,:), Bu(2,:), Bu(3,:), [0 0 0 0]);
                                    case 'monotone'
                                        pstruct = patch_add(pstruct, Bl(1,:), Bl(2,:), Bl(3,:));
                                        pstruct = patch_add(pstruct, Bu(1,:), Bu(2,:), Bu(3,:));
                                end
                                
                                for side = 1:4
                                    i1 = side;
                                    i2 = mod(side,4) + 1;
                                    
                                    x = [Bu(1,i1) Bu(1, i2) Bl(1,i2) Bl(1,i1)];
                                    y = [Bu(2,i1) Bu(2, i2) Bl(2,i2) Bl(2,i1)];
                                    z = [Bu(3,i1) Bu(3, i2) Bl(3,i2) Bl(3,i1)];
                                    Cs = [0 0 0 0];
                                    
                                    switch colormode
                                        case 'rainbow'
                                            pstruct = patch_add(pstruct, x, y, z, Cs);
                                        case 'monotone'
                                            pstruct = patch_add(pstruct, x, y, z);
                                    end
                                end
                                
                            end
                        end
                    end
                end
                
            end
        end
    case 'continuous'
        pstruct = patch_add(pstruct, su(1,:), su(2,:), su(3,:), color);
        pstruct = patch_add(pstruct, sl(1,:), sl(2,:), sl(3,:), color);
        for side = 1:4
            i1 = side;
            i2 = mod(side,4) + 1;
            x = [su(1,i1) su(1, i2) sl(1,i2) sl(1,i1)];
            y = [su(2,i1) su(2, i2) sl(2,i2) sl(2,i1)];
            z = [su(3,i1) su(3, i2) sl(3,i2) sl(3,i1)];
            pstruct = patch_add(pstruct, x, y, z, color);
        end
end

%% Patch!
if ~isempty(removal_depth)
    pstruct = RemoveInside(pstruct, removal_depth, s, xu, yu);
end
switch colormode
    case 'monotone'
        n = size(pstruct.x, 2);
        pstruct.c = 0.8*ones(1,n,3);
end
patch(pstruct.x, pstruct.y, pstruct.z, pstruct.c)

%% For the flexures
Theta{zu+1} = eye(3); % For the ground
Delta{zu+1} = zeros(3,1); % For the ground
zc(zu+1) = -zu*s+t;
Lx = zeros(2, size(Constraint,1));
Ly = zeros(2, size(Constraint,1));
Lz = zeros(2, size(Constraint,1));
for a = 1:size(Constraint, 1)
    i1 = Constraint(a,7);
    i2 = Constraint(a,7)+1;
    
    L1 = [xc yc zc(i1)]';
    L2 = [xc yc zc(i2)]';
    
    p1 = Constraint(a,1:3)';
    p2 = Constraint(a,4:6)';
    
    p1t = Theta{i1}*(p1-L1) + Delta{i1} + L1;
    p2t = Theta{i2}*(p2-L2) + Delta{i2} + L2;
    
    x1 = p1t(1);
    y1 = p1t(2);
    z1 = p1t(3);
    
    x2 = p2t(1);
    y2 = p2t(2);
    z2 = p2t(3);
    
    Lx(:,a) = [x1; x2];
    Ly(:,a) = [y1; y2];
    Lz(:,a) = [z1; z2];
    
    %     switch colormode
    %         case 'rainbow'
    %             plot3([x1 x2],[y1 y2],[z1 z2],'Color','k','LineWidth',2.5)
    %         case 'monotone'
    %             plot3([x1 x2],[y1 y2],[z1 z2],'Color','b','LineWidth',2.5)
    %     end
end

if ~isempty(removal_depth)
    [Lx, Ly, Lz] = RemoveInsideWires(Lx, Ly, Lz, removal_depth, s, xu, yu);
end

switch colormode
    case 'rainbow'
        %         plot3(Lx, Ly, Lz,'Color','k','LineWidth',2.5)
        line(Lx, Ly, Lz,'Color',[0 0 0],'LineWidth',2.5);
    case 'monotone'
        %         plot3(Lx, Ly, Lz,'Color','b','LineWidth',2.5)
        line(Lx, Ly, Lz,'Color',[0 0 0],'LineWidth',2.5);
end

if strcmp(colormode, 'rainbow')
    colormap('jet');
end
axis equal
function pstruct = patch_add(pstruct, x, y, z, c)
n = pstruct.n;
if size(x,1) == 1 && size(x,2) == 4
    pstruct.x(:,n) = x';
    pstruct.y(:,n) = y';
    pstruct.z(:,n) = z';
elseif size(x,1) == 4 && size(x,2) == 1
    pstruct.x(:,n) = x;
    pstruct.y(:,n) = y;
    pstruct.z(:,n) = z;
else error('patch_add dimension mismatch')
end

if nargin == 5
    if size(c,1) == 1 && size(c,2) == 4
        pstruct.c(:,n) = c';
    elseif size(c,1) == 4 && size(c,2) == 1
        pstruct.c(:,n) = c;
    elseif size(c,1) == 1 && size(c,2) == 3
        pstruct.c(1,n,:) = c;
    elseif size(c,1) == 3 && size(c,2) == 1
        pstruct.c(1,n,1) = c(1);
        pstruct.c(1,n,2) = c(2);
        pstruct.c(1,n,3) = c(3);
    elseif size(c,1) == 1 && size(c,2) == 1
        c = [c; c; c; c];
        %     pstruct.c = [pstruct.c, c];
        pstruct.c(:,n) = c;
    else error('patch_add dimension mismatch')
    end
end
pstruct.n = n + 1;
function n = EstimatePatches(xu, yu, zu, Dropdowns)
endcaps = xu*yu*2 + xu*2+yu*2;
middle = xu*yu*2 + xu*4+yu*4;
stages = endcaps + (zu-1)*middle;

dropdowns = length(Dropdowns)*5*2;

n = stages + dropdowns;
function view_iso_Callback(hObject, eventdata, handles)
view([135 25])
function view_side_Callback(hObject, eventdata, handles)
view([-90 0])
function view_side2_Callback(hObject, eventdata, handles)
view([0 0])
function pstruct = RemoveInside(pstruct, depth, s, xu, yu)
x = pstruct.x;
y = pstruct.y;
z = pstruct.z;

dx = xu*s - depth*s;
dy = yu*s - depth*s;
dz = depth*s;

bx = or(or(x(1,:) > dx, x(2,:) > dx), or(x(3,:) > dx, x(4,:) > dx));
by = or(or(y(1,:) > dy, y(2,:) > dy), or(y(3,:) > dy, y(4,:) > dy));
bz = or(or(z(1,:) > -dz, z(2,:) > -dz), or(z(3,:) > -dz, z(4,:) > -dz));

b = or(bx, or(by, bz));

pstruct.x = pstruct.x(:,b);
pstruct.y = pstruct.y(:,b);
pstruct.z = pstruct.z(:,b);
if isfield(pstruct,'c')
    if length(size(pstruct.c)) == 2
        pstruct.c = pstruct.c(:,b);
    else
        pstruct.c = pstruct.c(:,b,:);
    end
end
function [Lx, Ly, Lz] = RemoveInsideWires(Lx, Ly, Lz, depth, s, xu, yu)
dx = xu*s - depth*s;
dy = yu*s - depth*s;
dz = depth*s;

bx = or(Lx(1,:) > dx, Lx(2,:) > dx);
by = or(Ly(1,:) > dy, Ly(2,:) > dy);
bz = or(Lz(1,:) > -dz, Lz(2,:) > -dz);

b = or(bx, or(by, bz));
Lx = Lx(:,b);
Ly = Ly(:,b);
Lz = Lz(:,b);

%% Engine
function KK = EulerStiffnessMatrix(Constraint)
%Function reads in a matrix (Constraint) that contains all the Dropdowns needed
%to describe a flexure system, and returns its stiffness matrix

%Before you construct the matrix Constraint, be sure to number all of your
%system's rigid stages and number all of your flexure elements.  Grounded
%stages are numbered zero.

%Each row of the Constraint matrix corresponds to a flexure element.

%The following describes what each component of an individual row entails.
%the first 3 components are the chosen location vector, L, that points to
%one end of the element (the end doesn't matter but be consistent)
%the next 3 components are the direction of the n3 unit vector that points
%into the stage that the element attaches to along the element's axis.
%the next 3 components are the direction of the n2 unit vector that points
%perpendicular to the width, W, side of the rectangular element.  W is the
%length of the flat face of a blade flexure.
%the 10th component is the length of the element, L.
%the 11th component is the width of the element, W.
%the 12th component is the thickness of the element, t.
%the 13th component is the Young's Modulus of the material, E.
%the 14th component is the Shear Modulus of the material, G.
%the last two components correspond to what stages the element joings.
%start with the stage number that the chosen L vector points to and then
%end with the other stage that the element joins.

%Once you have filled a row with every element in the system make a final
%row that contains the following components:
%the 1st component is the number of stages in the system (excluding the
%ground, which is numbered 0).
%the 2nd component will always be zero.
%the 3rd component is how many rectangular elements are in the entire
%system.  Then fill the rest of the row with zeros.

[row, column]=size(Constraint);
stages=Constraint(row,1);
wire=Constraint(row,2);
blade=Constraint(row,3);
ConstNum=row-1;
MainMatrix=zeros(stages*6,stages*6);

NumStageConst=zeros(stages,1);
for i=1:ConstNum
    for j=1:stages
        if(Constraint(i,column-1)==j || Constraint(i,column)==j)
            NumStageConst(j,1)=NumStageConst(j,1)+1;
        end
    end
end

for j=1:stages
    Iden=zeros(6,6*NumStageConst(j,1));
    for k=0:NumStageConst(j,1)-1
        Iden(1:6,(k*6)+1:(k*6)+6)=eye(6);
    end
    WrenchMatrix=zeros(6*NumStageConst(j,1),6*stages);
    count=0;
    for i=1:wire
        if(Constraint(i,column-1)==j)
            count=count+1;
            %Construct S for wire flexure i
            ss=zeros(6,6);
            l=Constraint(i,10);
            d=Constraint(i,11);
            E=Constraint(i,13);
            G=Constraint(i,14);
            I=(pi*(d^4))/64;
            J=(pi*(d^4))/32;
            A=(pi*(d^2))/4;
            ss(1,1)=l/(E*I);
            ss(1,5)=-(l^2)/(2*E*I);
            ss(2,2)=l/(E*I);
            ss(2,4)=(l^2)/(2*E*I);
            ss(3,3)=l/(G*J);
            ss(4,2)=(l^2)/(2*E*I);
            ss(4,4)=(l^3)/(3*E*I);
            ss(5,1)=-(l^2)/(2*E*I);
            ss(5,5)=(l^3)/(3*E*I);
            ss(6,6)=l/(E*A);
            S=inv(ss);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            r=Constraint(i,1:3);
            n3=Constraint(i,4:6);
            n3=n3/sqrt(dot(n3,n3));
            orth=null(n3);
            n2=transpose(orth(1:3,1));
            n2=n2/sqrt(dot(n2,n2));
            n1=cross(n2,n3);
            Na=zeros(6,6);
            Na(1:3,1)=transpose(n1);
            Na(1:3,2)=transpose(n2);
            Na(1:3,3)=transpose(n3);
            Na(4:6,4)=transpose(n1);
            Na(4:6,5)=transpose(n2);
            Na(4:6,6)=transpose(n3);
            Na(4:6,1)=transpose(cross(r,n1));
            Na(4:6,2)=transpose(cross(r,n2));
            Na(4:6,3)=transpose(cross(r,n3));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            NR=zeros(6,6);
            NR(1:6,1:3)=Na(1:6,4:6);
            NR(1:6,4:6)=Na(1:6,1:3);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Nb=zeros(6,6);
            Nb(1:3,1)=transpose(n1);
            Nb(1:3,2)=transpose(n2);
            Nb(1:3,3)=transpose(n3);
            Nb(4:6,4)=transpose(n1);
            Nb(4:6,5)=transpose(n2);
            Nb(4:6,6)=transpose(n3);
            Nb(4:6,1)=transpose(cross((r-(l*n3)),n1));
            Nb(4:6,2)=transpose(cross((r-(l*n3)),n2));
            Nb(4:6,3)=transpose(cross((r-(l*n3)),n3));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            WrenchMatrix(((count-1)*6)+1:((count-1)*6)+6,((j-1)*6)+1:((j-1)*6)+6)=NR*S/(Na);
            if(Constraint(i,column)~=0)
                P=zeros(6,6);
                P(4,2)=-l;
                P(5,1)=l;
                WrenchMatrix(((count-1)*6)+1:((count-1)*6)+6,((Constraint(i,column)-1)*6)+1:((Constraint(i,column)-1)*6)+6)=NR*S*(P-eye(6))/(Nb);
            end
        elseif(Constraint(i,column)==j)
            count=count+1;
            %Construct S for wire flexure i
            ss=zeros(6,6);
            l=Constraint(i,10);
            d=Constraint(i,11);
            E=Constraint(i,13);
            G=Constraint(i,14);
            I=(pi*(d^4))/64;
            J=(pi*(d^4))/32;
            A=(pi*(d^2))/4;
            ss(1,1)=l/(E*I);
            ss(1,5)=-(l^2)/(2*E*I);
            ss(2,2)=l/(E*I);
            ss(2,4)=(l^2)/(2*E*I);
            ss(3,3)=l/(G*J);
            ss(4,2)=(l^2)/(2*E*I);
            ss(4,4)=(l^3)/(3*E*I);
            ss(5,1)=-(l^2)/(2*E*I);
            ss(5,5)=(l^3)/(3*E*I);
            ss(6,6)=l/(E*A);
            S=inv(ss);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            n3=-Constraint(i,4:6);
            n3=n3/sqrt(dot(n3,n3));
            r=Constraint(i,1:3)+l*n3;
            orth=null(n3);
            n2=transpose(orth(1:3,1));
            n2=n2/sqrt(dot(n2,n2));
            n1=cross(n2,n3);
            Na=zeros(6,6);
            Na(1:3,1)=transpose(n1);
            Na(1:3,2)=transpose(n2);
            Na(1:3,3)=transpose(n3);
            Na(4:6,4)=transpose(n1);
            Na(4:6,5)=transpose(n2);
            Na(4:6,6)=transpose(n3);
            Na(4:6,1)=transpose(cross(r,n1));
            Na(4:6,2)=transpose(cross(r,n2));
            Na(4:6,3)=transpose(cross(r,n3));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            NR=zeros(6,6);
            NR(1:6,1:3)=Na(1:6,4:6);
            NR(1:6,4:6)=Na(1:6,1:3);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Nb=zeros(6,6);
            Nb(1:3,1)=transpose(n1);
            Nb(1:3,2)=transpose(n2);
            Nb(1:3,3)=transpose(n3);
            Nb(4:6,4)=transpose(n1);
            Nb(4:6,5)=transpose(n2);
            Nb(4:6,6)=transpose(n3);
            Nb(4:6,1)=transpose(cross((r-(l*n3)),n1));
            Nb(4:6,2)=transpose(cross((r-(l*n3)),n2));
            Nb(4:6,3)=transpose(cross((r-(l*n3)),n3));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            WrenchMatrix(((count-1)*6)+1:((count-1)*6)+6,((j-1)*6)+1:((j-1)*6)+6)=NR*S/(Na);
            if(Constraint(i,column-1)~=0)
                P=zeros(6,6);
                P(4,2)=-l;
                P(5,1)=l;
                WrenchMatrix(((count-1)*6)+1:((count-1)*6)+6,((Constraint(i,column-1)-1)*6)+1:((Constraint(i,column-1)-1)*6)+6)=NR*S*(P-eye(6))/(Nb);
            end
        end
    end
    for i=1+wire:blade+wire
        if(Constraint(i,column-1)==j)
            count=count+1;
            %Construct S for blade flexure i
            ss=zeros(6,6);
            l=Constraint(i,10);
            w=Constraint(i,11);
            t=Constraint(i,12);
            E=Constraint(i,13);
            G=Constraint(i,14);
            I1=w*(t^3)/12;
            I2=t*(w^3)/12;
            Temp=0;
            if(w>t)
                for n=1:2:7
                    Temp=Temp+(tanh(n*pi*w/(2*t))/(n^5));
                end
                J=((t^3)*w/3)*(1-((192*t/((pi^5)*w))*Temp));
            else
                for n=1:2:7
                    Temp=Temp+(tanh(n*pi*t/(2*w))/(n^5));
                end
                J=((w^3)*t/3)*(1-((192*w/((pi^5)*t))*Temp));
            end
            A=w*t;
            ss(1,1)=l/(E*I1);
            ss(1,5)=-(l^2)/(2*E*I1);
            ss(2,2)=l/(E*I2);
            ss(2,4)=(l^2)/(2*E*I2);
            ss(3,3)=l/(G*J);
            ss(4,2)=(l^2)/(2*E*I2);
            ss(4,4)=(l^3)/(3*E*I2);
            ss(5,1)=-(l^2)/(2*E*I1);
            ss(5,5)=(l^3)/(3*E*I1);
            ss(6,6)=l/(E*A);
            S=inv(ss);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            r=Constraint(i,1:3);
            n3=Constraint(i,4:6);
            n3=n3/sqrt(dot(n3,n3));
            n2=Constraint(i,7:9);
            n2=n2/sqrt(dot(n2,n2));
            n1=cross(n2,n3);
            Na=zeros(6,6);
            Na(1:3,1)=transpose(n1);
            Na(1:3,2)=transpose(n2);
            Na(1:3,3)=transpose(n3);
            Na(4:6,4)=transpose(n1);
            Na(4:6,5)=transpose(n2);
            Na(4:6,6)=transpose(n3);
            Na(4:6,1)=transpose(cross(r,n1));
            Na(4:6,2)=transpose(cross(r,n2));
            Na(4:6,3)=transpose(cross(r,n3));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            NR=zeros(6,6);
            NR(1:6,1:3)=Na(1:6,4:6);
            NR(1:6,4:6)=Na(1:6,1:3);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Nb=zeros(6,6);
            Nb(1:3,1)=transpose(n1);
            Nb(1:3,2)=transpose(n2);
            Nb(1:3,3)=transpose(n3);
            Nb(4:6,4)=transpose(n1);
            Nb(4:6,5)=transpose(n2);
            Nb(4:6,6)=transpose(n3);
            Nb(4:6,1)=transpose(cross((r-(l*n3)),n1));
            Nb(4:6,2)=transpose(cross((r-(l*n3)),n2));
            Nb(4:6,3)=transpose(cross((r-(l*n3)),n3));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            WrenchMatrix(((count-1)*6)+1:((count-1)*6)+6,((j-1)*6)+1:((j-1)*6)+6)=NR*S/(Na);
            if(Constraint(i,column)~=0)
                P=zeros(6,6);
                P(4,2)=-l;
                P(5,1)=l;
                WrenchMatrix(((count-1)*6)+1:((count-1)*6)+6,((Constraint(i,column)-1)*6)+1:((Constraint(i,column)-1)*6)+6)=NR*S*(P-eye(6))/(Nb);
            end
        elseif(Constraint(i,column)==j)
            count=count+1;
            %Construct S for blade flexure i
            ss=zeros(6,6);
            l=Constraint(i,10);
            w=Constraint(i,11);
            t=Constraint(i,12);
            E=Constraint(i,13);
            G=Constraint(i,14);
            I1=w*(t^3)/12;
            I2=t*(w^3)/12;
            Temp=0;
            if(w>t)
                for n=1:2:7
                    Temp=Temp+(tanh(n*pi*w/(2*t))/(n^5));
                end
                J=((t^3)*w/3)*(1-((192*t/((pi^5)*w))*Temp));
            else
                for n=1:2:7
                    Temp=Temp+(tanh(n*pi*t/(2*w))/(n^5));
                end
                J=((w^3)*t/3)*(1-((192*w/((pi^5)*t))*Temp));
            end
            A=w*t;
            ss(1,1)=l/(E*I1);
            ss(1,5)=-(l^2)/(2*E*I1);
            ss(2,2)=l/(E*I2);
            ss(2,4)=(l^2)/(2*E*I2);
            ss(3,3)=l/(G*J);
            ss(4,2)=(l^2)/(2*E*I2);
            ss(4,4)=(l^3)/(3*E*I2);
            ss(5,1)=-(l^2)/(2*E*I1);
            ss(5,5)=(l^3)/(3*E*I1);
            ss(6,6)=l/(E*A);
            S=inv(ss);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            n3=-Constraint(i,4:6);
            n3=n3/sqrt(dot(n3,n3));
            r=Constraint(i,1:3)+l*n3;
            n2=Constraint(i,7:9);
            n2=n2/sqrt(dot(n2,n2));
            n1=cross(n2,n3);
            Na=zeros(6,6);
            Na(1:3,1)=transpose(n1);
            Na(1:3,2)=transpose(n2);
            Na(1:3,3)=transpose(n3);
            Na(4:6,4)=transpose(n1);
            Na(4:6,5)=transpose(n2);
            Na(4:6,6)=transpose(n3);
            Na(4:6,1)=transpose(cross(r,n1));
            Na(4:6,2)=transpose(cross(r,n2));
            Na(4:6,3)=transpose(cross(r,n3));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            NR=zeros(6,6);
            NR(1:6,1:3)=Na(1:6,4:6);
            NR(1:6,4:6)=Na(1:6,1:3);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Nb=zeros(6,6);
            Nb(1:3,1)=transpose(n1);
            Nb(1:3,2)=transpose(n2);
            Nb(1:3,3)=transpose(n3);
            Nb(4:6,4)=transpose(n1);
            Nb(4:6,5)=transpose(n2);
            Nb(4:6,6)=transpose(n3);
            Nb(4:6,1)=transpose(cross((r-(l*n3)),n1));
            Nb(4:6,2)=transpose(cross((r-(l*n3)),n2));
            Nb(4:6,3)=transpose(cross((r-(l*n3)),n3));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            WrenchMatrix(((count-1)*6)+1:((count-1)*6)+6,((j-1)*6)+1:((j-1)*6)+6)=NR*S/(Na);
            if(Constraint(i,column-1)~=0)
                P=zeros(6,6);
                P(4,2)=-l;
                P(5,1)=l;
                WrenchMatrix(((count-1)*6)+1:((count-1)*6)+6,((Constraint(i,column-1)-1)*6)+1:((Constraint(i,column-1)-1)*6)+6)=NR*S*(P-eye(6))/(Nb);
            end
        end
    end
    MainMatrix(((j-1)*6)+1:((j-1)*6)+6,1:(stages*6))=Iden*WrenchMatrix;
end

KK=MainMatrix;
function [c, w, p] = DecomposePlucker(T)
%Decomposes twist vectors into their pitch, location, and orientation
%vectors
%Input: Twist (6x1 matrix)
%Output: c=location vector w=orientation vector p=pitch

if(dot(T(1:3),T(1:3))<=1e-20)
    %pure translation
    c = NaN;
    w = [T(4) T(5) T(6)];  %Orientation vector defined
    p = inf;
else
    w = [T(1) T(2) T(3)];
    v = [T(4) T(5) T(6)];
    p = dot(w,v)/dot(w,w);
    c = [0 0 0];  %Initialize location vector
    if(w(1)==0 && w(2)==0)
        c(1) = -v(2)/w(3);
        c(2) = v(1)/w(3);
        c(3)= 0;
    elseif(w(1)==0 && w(3)==0)
        c(1) = v(3)/w(2);
        c(2) = 0;
        c(3) = -v(1)/w(2);
    elseif(w(2)==0 && w(3)==0)
        c(1) = 0;
        c(2) = -v(3)/w(1);
        c(3) = v(2)/w(1);
    elseif(w(1)==0)
        c(1) = (v(2)-p*w(2))/(-w(3));
        c(2) = v(1)/w(3);
        c(3)= 0;
    elseif(w(2)==0)
        c(1) = -v(2)/w(3);
        c(2) = (v(1)-p*w(1))/w(3);
        c(3)= 0;
    elseif(w(3)==0)
        c(1) = 0;
        c(2) = -v(3)/w(1);
        c(3) = (v(2)-p*w(2))/w(1);
    else
        c(1) = 0;
        c(2) = (v(3)-p*w(3))/(-w(1));
        c(3) = (v(2)-p*w(2))/w(1);
    end
    if(abs(c(1))>=1e5 && w(1)~=0)
        t=-c(1)/w(1);
        c=c+(w*t);
    elseif(abs(c(2))>=1e5 && w(2)~=0)
        t=-c(2)/w(2);
        c=c+(w*t);
    elseif(abs(c(3))>=1e5 && w(3)~=0)
        t=-c(3)/w(3);
        c=c+(w*t);
    end
end
function R = Rotation(tx, ty, tz)
Rx = [1 0 0; 0 cos(tx) -sin(tx); 0 sin(tx) cos(tx)];
Ry = [cos(ty) 0 sin(ty); 0 1 0; -sin(ty) 0 cos(ty)];
Rz = [cos(tz) -sin(tz) 0; sin(tz) cos(tz) 0; 0 0 1];

R = Rz*Ry*Rx;
function [Vscaled, scale] = ScaleTwist(V, s, xu, yu, zu)

max_theta = 0.15;
max_delta = max([xu yu zu])*s / 10;

theta = [V(1:6:end); V(2:6:end); V(3:6:end)];
theta_m = max(abs(theta));
theta_scale = max_theta / theta_m;

delta = [V(4:6:end); V(5:6:end); V(6:6:end)];
delta_m = max(abs(delta));
delta_scale = max_delta / delta_m;

[scale, I] = min(abs([theta_scale, delta_scale]));
Vscaled = V * scale;

if I == 1
    %     disp('Rotation-limited scaling applied')
elseif I == 2
    %     disp('Displacement-limited scaling applied')
end
function out = roundto(in,n)
out = round(in*10^n) * 10^-n;

%% Interactivity
function [DOF, type] = FACTselect(FACTimage, title_str)

if nargin == 0 || isempty(FACTimage)
    FACTimage = imread('FACTchart.png');
end

h_fig = figure('NumberTitle', 'off', 'Name', title_str);
set(gcf,'color','w');
set(gcf,'MenuBar','none')
set(gcf,'ToolBar','none')
% assignin('base','FACTimage',FACTimage)
try
    imshow(FACTimage);
catch
    image(FACTimage);
    axis equal
end
set(gcf,'color','w')
if nargin == 2
    title(title_str, 'FontSize', 14)
end

d0t1 = [17 704 136 53];

d1t1 = [155 695 133 61];
d1t2 = [155 636 133 61];
d1t3 = [155 588 133 50];

d2t3 = [291 581 133 77];
d2t4 = [291 526 133 62];
d2t5 = [291 468 132 69];
d2t6 = [291 403 128 67];
d2t7 = [291 338 132 71];
d2t8 = [291 291 132 55];
d2t9 = [291 238 135 56];

d3t2 = [430 660 131 59];
d3t3 = [428 591 132 65];

try
    [x, y] = cinput(1);
catch
    DOF = [];
    type = [];
    return;
end

if InBox([x, y], d0t1)
    DOF = 0; type = 1;
    
elseif InBox([x, y], d1t1)
    DOF = 1; type = 1;
elseif InBox([x, y], d1t2)
    DOF = 1; type = 2;
elseif InBox([x, y], d1t3)
    DOF = 1; type = 3;
    
elseif InBox([x, y], d2t3)
    DOF = 2; type = 3;
elseif InBox([x, y], d2t4)
    DOF = 2; type = 4;
elseif InBox([x, y], d2t5)
    DOF = 2; type = 5;
elseif InBox([x, y], d2t6)
    DOF = 2; type = 6;
elseif InBox([x, y], d2t7)
    DOF = 2; type = 7;
elseif InBox([x, y], d2t8)
    DOF = 2; type = 8;
elseif InBox([x, y], d2t9)
    DOF = 2; type = 9;
    
elseif InBox([x, y], d3t2)
    DOF = 3; type = 2;
elseif InBox([x, y], d3t3)
    DOF = 3; type = 3;
else
    DOF = []; type = [];
end

close(h_fig)
function varargout = cinput(arg1)
%GINPUT Graphical input from mouse.
%   [X,Y] = CINPUT(N) gets N points from the current axes and returns
%   the X- and Y-coordinates in length N vectors X and Y.  The cursor
%   can be positioned using a mouse.  Data points are entered by pressing
%   a mouse button or any key on the keyboard except carriage return,
%   which terminates the input before N points are entered.
%
%   [X,Y] = CINPUT gathers an unlimited number of points until the
%   return key is pressed.
%
%   [X,Y,BUTTON] = CINPUT(N) returns a third result, BUTTON, that
%   contains a vector of integers specifying which mouse button was
%   used (1,2,3 from left) or ASCII numbers if a key on the keyboard
%   was used.
%
%   Examples:
%       [x,y] = cinput;
%
%       [x,y] = cinput(5);
%
%       [x, y, button] = cinput(1);
%
%   See also GTEXT, WAITFORBUTTONPRESS.

%   Copyright 1984-2013 The MathWorks, Inc.

x = []; y = []; userInputs = [];

if ~matlab.ui.internal.isFigureShowEnabled
    error(message('MATLAB:hg:NoDisplayNoFigureSupport', 'ginput'))
end

% Check inputs
if nargin == 0
    how_many = -1;
else
    how_many = arg1;
    
    if ~isPositiveScalarIntegerNumber(how_many)
        error(message('MATLAB:ginput:NeedPositiveInt'))
    end
    if how_many == 0
        % If input argument is equal to zero points,
        % give a warning and return empty for the outputs.
        warning (message('MATLAB:ginput:InputArgumentZero'));
    end
end

% Get figure
fig = gcf;
figure(fig);

% Make sure the figure has an axes
gca(fig);

% Setup the figure to disable interactive modes and activate pointers.
initialState = setupFcn(fig);

% onCleanup object to restore everything to original state in event of
% completion, closing of figure errors or ctrl+c.
c = onCleanup(@() restoreFcn(initialState));

drawnow
char = 0;

while how_many ~= 0
    try
        mode = waitForUserInput(fig);
    catch %#ok<CTCH>
        cleanup(c);
        if(ishghandle(fig))
            error(message('MATLAB:ginput:Interrupted'));
        else
            error(message('MATLAB:ginput:FigureDeletionPause'));
        end
    end
    
    
    % Make sure figure has not been closed
    checkFigureAvailable();
    
    if (isCorrectFigure(fig))
        switch mode
            case 'key'
                char = get(fig, 'CurrentCharacter');
                curUserInput = abs(get(fig, 'CurrentCharacter'));
            case 'mouse'
                curUserInput = get(fig, 'SelectionType');
                if strcmp(curUserInput,'open')
                    curUserInput = 1;
                elseif strcmp(curUserInput,'normal')
                    curUserInput = 1;
                elseif strcmp(curUserInput,'extend')
                    curUserInput = 2;
                elseif strcmp(curUserInput,'alt')
                    curUserInput = 3;
                else
                    error(message('MATLAB:ginput:InvalidSelection'))
                end
        end
        axes_handle = get(fig,'CurrentAxes');
        pt = get(axes_handle, 'CurrentPoint');
        
        how_many = how_many - 1;
        
        if(char == 13)
            % if the return key was pressed, char will == 13,
            % and that's our signal to break out of here whether
            % or not we have collected all the requested data
            % points.
            % If this was an early breakout, don't include
            % the <Return> key Dropdowns in the return arrays.
            % We will no longer count it if it's the last input.
            break;
        end
        
        x = [x;pt(1,1)]; %#ok<AGROW>
        y = [y;pt(1,2)]; %#ok<AGROW>
        userInputs = [userInputs;curUserInput]; %#ok<AGROW>
    end
end

% Cleanup and Restore
cleanup(c);

if nargout == 1
    varargout{1} = [x y];
else
    varargout{1} = x;
end
if nargout > 1
    varargout{2} = y;
end
if nargout > 2
    varargout{3} = userInputs;
end
function valid = isPositiveScalarIntegerNumber(how_many)

valid = ~ischar(how_many) && ...            % is numeric
    isscalar(how_many) && ...           % is scalar
    (fix(how_many) == how_many) && ...  % is integer in value
    how_many >= 0;                      % is positive
function mode = waitForUserInput(fig)
waitfor(fig,'UserData')
% Extract mode to determine if key or mouse was used
mode = get(fig,'UserData');
if ischar(mode)
    ud = strsplit(mode, '_');
    mode = ud{1};
end% Reset user data to prepare for next trigger
set(fig,'UserData',[])
function initialState = setupFcn(fig)

% Store Figure Handle.
initialState.figureHandle = fig;

% Suspend figure functions
initialState.uisuspendState = uisuspend(fig);

% Disabling ^C for edit menu so the only ^C is for interrupting the function
initialState.AcceleratorMenu = findall(fig,'Type','uimenu','Accelerator','C');
set(initialState.AcceleratorMenu,'Accelerator','');

% Extract user data
initialState.PreviousUserData = get(fig,'UserData');

% Set callbacks to distinguish from key and mouse triggers
% Using random numbers to distinguish things like double clicks.
set(fig, 'WindowButtondownFcn', @(~,~)set(fig, 'UserData', ['mouse_' num2str(rand)]));
set(fig, 'WindowKeyPressFcn', @(~,~) set(fig, 'UserData', ['key_' num2str(rand)]));

% Disable Plottools Buttons
initialState.toolbar = findobj(allchild(fig),'flat','Type','uitoolbar');
if ~isempty(initialState.toolbar)
    initialState.ptButtons = [uigettool(initialState.toolbar,'Plottools.PlottoolsOff'), ...
        uigettool(initialState.toolbar,'Plottools.PlottoolsOn')];
    initialState.ptState = get (initialState.ptButtons,'Enable');
    set (initialState.ptButtons,'Enable','off');
end

%Setup empty pointer
P = ones(16)+1;
P(1,:) = 1; P(16,:) = 1;
P(:,1) = 1; P(:,16) = 1;
P(1:4,8:9) = 1; P(13:16,8:9) = 1;
P(8:9,1:4) = 1; P(8:9,13:16) = 1;
P(5:12,5:12) = NaN; % Create a transparent region in the center
cdata = P;
hotspot = [9, 9];
set(gcf,'Pointer','custom','PointerShapeCData',cdata,'PointerShapeHotSpot',hotspot)

% Get the initial Figure Units
initialState.fig_units = get(fig,'Units');
function restoreFcn(initialState)
if ishghandle(initialState.figureHandle)
    
    % Figure Units
    set(initialState.figureHandle,'Units',initialState.fig_units);
    
    % Reset user data
    set(initialState.figureHandle,'UserData',initialState.PreviousUserData)
    
    % Enable Ctrl+c
    set(initialState.AcceleratorMenu,'Accelerator','C');
    
    % Plottools Icons
    if ~isempty(initialState.toolbar) && ~isempty(initialState.ptButtons)
        set (initialState.ptButtons(1),'Enable',initialState.ptState{1});
        set (initialState.ptButtons(2),'Enable',initialState.ptState{2});
    end
    
    % UISUSPEND
    uirestore(initialState.uisuspendState);
end
function updateCrossHair(fig, crossHair)
% update cross hair for figure.
gap = 3; % 3 pixel view port between the crosshairs
cp = hgconvertunits(fig, [fig.CurrentPoint 0 0], fig.Units, 'pixels', fig);
cp = cp(1:2);
figPos = hgconvertunits(fig, fig.Position, fig.Units, 'pixels', fig.Parent);
figWidth = figPos(3);
figHeight = figPos(4);

% Early return if point is outside the figure
if cp(1) < gap || cp(2) < gap || cp(1)>figWidth-gap || cp(2)>figHeight-gap
    return
end

set(crossHair, 'Visible', 'on');
thickness = 1; % 1 Pixel thin lines.
set(crossHair(1), 'Position', [0 cp(2) cp(1)-gap thickness]);
set(crossHair(2), 'Position', [cp(1)+gap cp(2) figWidth-cp(1)-gap thickness]);
set(crossHair(3), 'Position', [cp(1) 0 thickness cp(2)-gap]);
set(crossHair(4), 'Position', [cp(1) cp(2)+gap thickness figHeight-cp(2)-gap]);
function checkFigureAvailable()
% See if root has children
figchildren = allchild(0);
if isempty(figchildren)
    error(message('MATLAB:ginput:FigureUnavailable'));
end
function valid = isCorrectFigure(fig)
% g467403 - ginput failed to discern clicks/keypressed on the figure it was
% registered to if the figure's handleVisibility was set to 'callback'
figchildren = allchild(0);
% Select figure at top
ptr_fig = figchildren(1);
% Check if they match
valid = isequal(ptr_fig,fig);
function cleanup(c)
if isvalid(c)
    delete(c);
end
function bool = InBox(pt, rect)

xbool = and(pt(1) > rect(1), pt(1) < (rect(1)+rect(3)));
ybool = and(pt(2) > rect(2), pt(2) < (rect(2)+rect(4)));

bool = and(xbool, ybool);
function shutdown(min)
%% Shuts down the computer after the number of minutes specified in shutdown(min)

for m = 1:min
    for s = 1:60
        pause(1);
        clc;
        
        hour = num2str(floor(((min-1)/60)));
        
        minute = mod(min-m,60);
        if minute < 10
            minute = ['0' num2str(minute)];
        else
            minute = num2str(minute);
        end
        
        sec = 60-s;
        if sec < 10
            sec = ['0' num2str(sec)];
        else
            sec = num2str(sec);
        end
        
        disp([hour ':' minute ':' sec ' remaining until shutdown'])
    end
end
clc; disp('Shutting down')

%% Shutdown
system('shutdown -s')

%% STL saving
function step4_saveSTL_Callback(hObject, eventdata, handles)
xu = str2double(handles.geometry{1});
yu = str2double(handles.geometry{2});
zu = str2double(handles.geometry{3});
s = str2double(handles.geometry{4});
t = str2double(handles.geometry{5});
r = str2double(handles.geometry{6});
n_cells = xu*yu*zu;

if n_cells >= 36
    str = ['You are about to export a design with ' num2str(n_cells) ' unit cells. This operation may take a while - do you wish to proceed?'];
    Button = questdlg(str, 'Export warning', 'Proceed', 'Cancel', 'Cancel');
    if strcmp(Button, 'Cancel'); return; end
end

[filename, pathname] = uiputfile('*.stl','Save .stl file as');
if isequal(filename,0) || isequal(pathname,0); return; end

fv = PrepareData4STL(filename, pathname, handles.Constraint, handles.Dropdowns, xu, yu, zu, s, t, r);
file = dir(filename);
str = ['Exported ' filename ' with ' num2str(size(fv.faces,1)) ' faces (' num2str(file.bytes/1e6, 3) ' MB)'];
title_str = 'STL exported';
msgbox(str, title_str);
function fv = PrepareData4STL(filename, pathname, Constraint, Dropdowns, xu, yu, zu, s, t, R)

unit_conversion = 1000;

N = 20; % wire flexure resolution

fv.vertices = zeros(0,3);
fv.faces = zeros(0,3);

hbar = waitbar(0,'Compiling STL data...');
for k = 1:length(Constraint)
    try waitbar(k/length(Constraint)*0.8, hbar); end
    scale = R/4;
    
    row = Constraint(k,1:6);
    
    dx = row(4)-row(1);
    dy = row(5)-row(2);
    dz = row(6)-row(3);
    
    L = sqrt( dx^2 + dy^2 + dz^2 );
    
    theta_elongation = acos(abs(dz/L)); % Angle for elongation, 0 is straight up
    d_elongation = scale * tan(theta_elongation) * 0.9;
    
    [x, y, z] = cylinder([1 1], N);
    x = reshape(x,size(x,1)*size(x,2),1);
    y = reshape(y,size(y,1)*size(y,2),1);
    z = reshape(z,size(z,1)*size(z,2),1);
    
    % Scaling
    x = x * scale;
    y = y * scale;
    z = z*L;
    z(z ~= 0) = z(z ~= 0) + d_elongation;
    z(z == 0) = -d_elongation;
    
    % Rotation
    P = [x'; y'; z'];
    
    r = hypot(dx, dy);
    theta = atan2(r, -dz);
    ty = theta;
    
    phi = atan2(dy, dx);
    tz = phi+pi;
    
    Ry = [cos(ty) 0 sin(ty); 0 1 0; -sin(ty) 0 cos(ty)];
    Rz = [cos(tz) -sin(tz) 0; sin(tz) cos(tz) 0; 0 0 1];
    
    P = Rz*Ry*P;
    
    x = P(1,:)';
    y = P(2,:)';
    z = P(3,:)';
    
    % Translation
    x = x + row(4); x(end-1:end) = [];
    y = y + row(5); y(end-1:end) = [];
    z = z + row(6); z(end-1:end) = [];
    
    % Triangulate
    if ~exist('tri','var')
        tri = convhull(x,y,z);
    end
    
    fv.vertices = [fv.vertices; x, y, z];
    
    offset = size(x,1);
    fv.faces = [fv.faces; tri+offset*(k-1)];
end

% Stages
clear tri
zvec = 0 : -s : -zu*s;
for z = zvec
    try waitbar(z/length(zvec)/10+0.8, hbar); end
    if z == 0
        z1 = z;
        z2 = z-t;
    elseif z == zvec(end)
        z1 = z + t;
        z2 = z;
    else
        z1 = z + t;
        z2 = z - t;
    end
    
    x1 = 0;
    x2 = xu * s;
    y1 = 0;
    y2 = yu * s;
    
    x = [x1 x2 x2 x1]';
    y = [y1 y1 y2 y2]';
    Z1 = [z1 z1 z1 z1]';
    Z2 = [z2 z2 z2 z2]';
    
    if ~exist('tri','var')
        tri = convhull([x; x],[y; y],[Z1; Z2]);
    end
    
    len = size(fv.vertices, 1);
    fv.vertices = [fv.vertices; x, y, Z1; x, y, Z2];
    fv.faces = [fv.faces; tri + len];
end

% Dropdowns
clear tri1 tri2
for k = 1:length(Dropdowns)
    try waitbar(k/length(Dropdowns)/20+0.9, hbar); end
    xc = Dropdowns(k).x;
    yc = Dropdowns(k).y;
    zc = Dropdowns(k).z;
    d = Dropdowns(k).d;
    side = Dropdowns(k).side;
    
    % Top side
    switch side
        case '+x'
            x1 = s - t;
            x2 = s;
            y1 = 0;
            y2 = s;
            z1 = s/2 - t;
            z2 = s/2 - t - d;
        case '-x'
            x1 = 0;
            x2 = t;
            y1 = 0;
            y2 = s;
            z1 = s/2 - t;
            z2 = s/2 - t - d;
        case '+y'
            x1 = 0;
            x2 = s;
            y1 = s - t;
            y2 = s;
            z1 = s/2 - t;
            z2 = s/2 - t - d;
        case '-y'
            x1 = 0;
            x2 = s;
            y1 = 0;
            y2 = t;
            z1 = s/2 - t;
            z2 = s/2 - t - d;
    end
    
    x = [x1 x2 x2 x1]';
    y = [y1 y1 y2 y2]';
    Z1 = [z1 z1 z1 z1]';
    Z2 = [z2 z2 z2 z2]';
    X = [x; x]-s/2;
    Y = [y; y]-s/2;
    Z = [Z1; Z2];
    
    Xtop = X + (xc-1)*s + s/2;
    Ytop = Y + (yc-1)*s + s/2;
    Ztop = Z - s/2 - (zc-1)*s;
    
    tx = pi;
    ty = pi;
    Rx = [1 0 0; 0 cos(tx) -sin(tx); 0 sin(tx) cos(tx)];
    Ry = [cos(ty) 0 sin(ty); 0 1 0; -sin(ty) 0 cos(ty)];
    
    switch side
        case '+x'
            bottom = Ry*[X'; Y'; Z'];
        case '-x'
            bottom = Ry*[X'; Y'; Z'];
        case '+y'
            bottom = Rx*[X'; Y'; Z'];
        case '-y'
            bottom = Rx*[X'; Y'; Z'];
    end
    
    Xbottom = bottom(1,:)' + (xc-1)*s + s/2;
    Ybottom = bottom(2,:)' + (yc-1)*s + s/2;
    Zbottom = bottom(3,:)' - s/2 - (zc-1)*s;
    
    if ~exist('tri1','var')
        tri1 = convhull(Xtop, Ytop, Ztop);
    end
    len = size(fv.vertices, 1);
    fv.vertices = [fv.vertices; Xtop, Ytop, Ztop];
    fv.faces = [fv.faces; tri + len];
    
    if ~exist('tri2','var')
        tri2 = convhull(Xbottom, Ybottom, Zbottom);
    end
    len = size(fv.vertices, 1);
    fv.vertices = [fv.vertices; Xbottom, Ybottom, Zbottom];
    fv.faces = [fv.faces; tri + len];
end

% Plot
figure;
trimesh(fv.faces, fv.vertices(:,1), fv.vertices(:,2), fv.vertices(:,3), zeros(size(fv.vertices(:,3))));
axis equal
view(3)
xlabel('x [m]')
ylabel('y [m]')
zlabel('z [m]')
title(['File exported: ' filename])
set(gcf,'color','w')
xlim([-s (xu+1)*s])
ylim([-s (yu+1)*s])
zlim([-s*(zu+1) s])
view([135 20])

try waitbar(0.95,hbar,'Writing STL...'); end

fv.vertices = fv.vertices * unit_conversion;

stlwrite([pathname filename],fv)
try delete(hbar); end
function stlwrite(filename, varargin)
% stlwrite source code from MathWorks File Exchange
% https://www.mathworks.com/matlabcentral/fileexchange/20922
% Accessed: 3/31/2018
%
% Copyright (c) 2015, Sven Holcombe
% All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
%
%     * Redistributions of source code must retain the above copyright
%       notice, this list of conditions and the following disclaimer.
%     * Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in
%       the documentation and/or other materials provided with the distribution
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.

% Original idea adapted from surf2stl by Bill McDonald. Huge speed
% improvements implemented by Oliver Woodford. Non-Delaunay triangulation
% of quadrilateral surface courtesy of Kevin Moerman. FaceColor
% implementation by Grant Lohsen.
%
% Author: Sven Holcombe, 11-24-11

% Check valid filename path
path = fileparts(filename);
if ~isempty(path) && ~exist(path,'dir')
    error('Directory "%s" does not exist.',path);
end

% Get faces, vertices, and user-defined options for writing
[faces, vertices, options] = parseInputs(varargin{:});
asciiMode = strcmp( options.mode ,'ascii');

% Create the facets
facets = single(vertices');
facets = reshape(facets(:,faces'), 3, 3, []);

% Compute their normals
V1 = squeeze(facets(:,2,:) - facets(:,1,:));
V2 = squeeze(facets(:,3,:) - facets(:,1,:));
normals = V1([2 3 1],:) .* V2([3 1 2],:) - V2([2 3 1],:) .* V1([3 1 2],:);
clear V1 V2
normals = bsxfun(@times, normals, 1 ./ sqrt(sum(normals .* normals, 1)));
facets = cat(2, reshape(normals, 3, 1, []), facets);
clear normals

% Open the file for writing
permissions = {'w','wb+'};
fid = fopen(filename, permissions{asciiMode+1});
if (fid == -1)
    error('stlwrite:cannotWriteFile', 'Unable to write to %s', filename);
end

% Write the file contents
if asciiMode
    % Write HEADER
    fprintf(fid,'solid %s\r\n',options.title);
    % Write DATA
    fprintf(fid,[...
        'facet normal %.7E %.7E %.7E\r\n' ...
        'outer loop\r\n' ...
        'vertex %.7E %.7E %.7E\r\n' ...
        'vertex %.7E %.7E %.7E\r\n' ...
        'vertex %.7E %.7E %.7E\r\n' ...
        'endloop\r\n' ...
        'endfacet\r\n'], facets);
    % Write FOOTER
    fprintf(fid,'endsolid %s\r\n',options.title);
    
else % BINARY
    % Write HEADER
    fprintf(fid, '%-80s', options.title);             % Title
    fwrite(fid, size(facets, 3), 'uint32');           % Number of facets
    % Write DATA
    % Add one uint16(0) to the end of each facet using a typecasting trick
    facets = reshape(typecast(facets(:), 'uint16'), 12*2, []);
    % Set the last bit to 0 (default) or supplied RGB
    facets(end+1,:) = options.facecolor;
    fwrite(fid, facets, 'uint16');
end

% Close the file
fclose(fid);
function [faces, vertices, options] = parseInputs(varargin)
% Determine input type
if isstruct(varargin{1}) % stlwrite('file', FVstruct, ...)
    if ~all(isfield(varargin{1},{'vertices','faces'}))
        error( 'Variable p must be a faces/vertices structure' );
    end
    faces = varargin{1}.faces;
    vertices = varargin{1}.vertices;
    options = parseOptions(varargin{2:end});
    
elseif isnumeric(varargin{1})
    firstNumInput = cellfun(@isnumeric,varargin);
    firstNumInput(find(~firstNumInput,1):end) = 0; % Only consider numerical input PRIOR to the first non-numeric
    numericInputCnt = nnz(firstNumInput);
    
    options = parseOptions(varargin{numericInputCnt+1:end});
    switch numericInputCnt
        case 3 % stlwrite('file', X, Y, Z, ...)
            % Extract the matrix Z
            Z = varargin{3};
            
            % Convert scalar XY to vectors
            ZsizeXY = fliplr(size(Z));
            for i = 1:2
                if isscalar(varargin{i})
                    varargin{i} = (0:ZsizeXY(i)-1) * varargin{i};
                end
            end
            
            % Extract X and Y
            if isequal(size(Z), size(varargin{1}), size(varargin{2}))
                % X,Y,Z were all provided as matrices
                [X,Y] = varargin{1:2};
            elseif numel(varargin{1})==ZsizeXY(1) && numel(varargin{2})==ZsizeXY(2)
                % Convert vector XY to meshgrid
                [X,Y] = meshgrid(varargin{1}, varargin{2});
            else
                error('stlwrite:badinput', 'Unable to resolve X and Y variables');
            end
            
            % Convert to faces/vertices
            if strcmp(options.triangulation,'delaunay')
                faces = delaunay(X,Y);
                vertices = [X(:) Y(:) Z(:)];
            else
                if ~exist('mesh2tri','file')
                    error('stlwrite:missing', '"mesh2tri" is required to convert X,Y,Z matrices to STL. It can be downloaded from:\n%s\n',...
                        'http://www.mathworks.com/matlabcentral/fileexchange/28327')
                end
                [faces, vertices] = mesh2tri(X, Y, Z, options.triangulation);
            end
            
        case 2 % stlwrite('file', FACES, VERTICES, ...)
            faces = varargin{1};
            vertices = varargin{2};
            
        otherwise
            error('stlwrite:badinput', 'Unable to resolve input types.');
    end
end

if ~isempty(options.facecolor) % Handle colour preparation
    facecolor = uint16(options.facecolor);
    %Set the Valid Color bit (bit 15)
    c0 = bitshift(ones(size(faces,1),1,'uint16'),15);
    %Red color (10:15), Blue color (5:9), Green color (0:4)
    c0 = bitor(bitshift(bitand(2^6-1, facecolor(:,1)),10),c0);
    c0 = bitor(bitshift(bitand(2^11-1, facecolor(:,2)),5),c0);
    c0 = bitor(bitand(2^6-1, facecolor(:,3)),c0);
    options.facecolor = c0;
else
    options.facecolor = 0;
end
function options = parseOptions(varargin)
IP = inputParser;
IP.addParamValue('mode', 'binary', @ischar)
IP.addParamValue('title', sprintf('Created by stlwrite.m %s',datestr(now)), @ischar);
IP.addParamValue('triangulation', 'delaunay', @ischar);
IP.addParamValue('facecolor',[], @isnumeric)
IP.addParamValue('facecolour',[], @isnumeric)
IP.parse(varargin{:});
options = IP.Results;
if ~isempty(options.facecolour)
    options.facecolor = options.facecolour;
end
function [F,V] = mesh2tri(X,Y,Z,tri_type)
% function [F,V]=mesh2tri(X,Y,Z,tri_type)
%
% Available from http://www.mathworks.com/matlabcentral/fileexchange/28327
% Included here for convenience. Many thanks to Kevin Mattheus Moerman
% kevinmoerman@hotmail.com
% 15/07/2010
%------------------------------------------------------------------------

[J,I]=meshgrid(1:1:size(X,2)-1,1:1:size(X,1)-1);

switch tri_type
    case 'f'%Forward slash
        TRI_I=[I(:),I(:)+1,I(:)+1;  I(:),I(:),I(:)+1];
        TRI_J=[J(:),J(:)+1,J(:);   J(:),J(:)+1,J(:)+1];
        F = sub2ind(size(X),TRI_I,TRI_J);
    case 'b'%Back slash
        TRI_I=[I(:),I(:)+1,I(:);  I(:)+1,I(:)+1,I(:)];
        TRI_J=[J(:)+1,J(:),J(:);   J(:)+1,J(:),J(:)+1];
        F = sub2ind(size(X),TRI_I,TRI_J);
    case 'x'%Cross
        TRI_I=[I(:)+1,I(:);  I(:)+1,I(:)+1;  I(:),I(:)+1;    I(:),I(:)];
        TRI_J=[J(:),J(:);    J(:)+1,J(:);    J(:)+1,J(:)+1;  J(:),J(:)+1];
        IND=((numel(X)+1):numel(X)+prod(size(X)-1))';
        F = sub2ind(size(X),TRI_I,TRI_J);
        F(:,3)=repmat(IND,[4,1]);
        Fe_I=[I(:),I(:)+1,I(:)+1,I(:)]; Fe_J=[J(:),J(:),J(:)+1,J(:)+1];
        Fe = sub2ind(size(X),Fe_I,Fe_J);
        Xe=mean(X(Fe),2); Ye=mean(Y(Fe),2);  Ze=mean(Z(Fe),2);
        X=[X(:);Xe(:)]; Y=[Y(:);Ye(:)]; Z=[Z(:);Ze(:)];
end

V=[X(:),Y(:),Z(:)];
